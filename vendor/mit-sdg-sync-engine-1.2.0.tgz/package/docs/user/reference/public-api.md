# Public API

This reference lists every supported core subpath and export. Root and deep
imports are unsupported. Registers are exact; generated TypeScript declarations
define complete signatures.

The [support policy](../../../SUPPORT.md) defines stable compatibility,
generated-assembly compatibility, and format-version rules. The
[security policy](../../../SECURITY.md) defines the supported security-fix window.

| Package path                                 | Role                                                                 |
| -------------------------------------------- | -------------------------------------------------------------------- |
| [`@mit-sdg/sync-engine/language`](#language) | Concepts, reactions, views, formers, and their conditions            |
| [`@mit-sdg/sync-engine/assembly`](#assembly) | Concept registration, assembly lifecycle, retention, and audit sinks |
| [`@mit-sdg/sync-engine/boundary`](#boundary) | Endpoints, invocation, gateways, and transport binding               |
| [`@mit-sdg/sync-engine/client`](#client)     | Local and custom clients over a generated contract                   |
| [`@mit-sdg/sync-engine/tooling`](#tooling)   | Assembly inspection, read-back rendering, and wire generation        |
| [`@mit-sdg/sync-engine/advanced`](#advanced) | Low-level declarations, manual engines, and explicit escape hatches  |

## `language`

<!-- register:language:start -->

`Condition`, `QueryPromise`, `ReadLine`, `RelationView`, `count`, `compute`, `each`, `earlier`, `form`, `former`, `is`, `no`, `now`, `reaction`, `refused`, `returned`, `view`, `when`, `where`, `whether`

<!-- register:language:end -->

`language` declares but does not execute designs.

| API                    | Compact signature                                                                               |
| ---------------------- | ----------------------------------------------------------------------------------------------- |
| `reaction`             | `reaction(vars => when(trigger).where(...conditions).then(...consequences))`                    |
| `.afterFlowSettles()`  | `when(trigger).afterFlowSettles().then(step)` or `completedStage.afterFlowSettles().then(step)` |
| `returned` / `refused` | `(pattern?, { by?, except?, exceptBy? }?)`                                                      |
| `where`                | `where(...conditions)`                                                                          |
| `no` / `whether`       | `(readLine)`                                                                                    |
| `earlier`              | `earlier(action, input, output?)`                                                               |
| `now`                  | `now(variable)`                                                                                 |
| `view`                 | `view(name, (input, output, free) => where(...))`                                               |
| `count`                | `count(query, input, outputVariable)`                                                           |
| `compute`              | `compute(namedComputation, input, outputVariable \| outputPattern)`                             |
| `former`               | `former(name, (input, free) => form(...) \| where(...).form(...))`                              |
| `form`                 | `form({ ...shape })`                                                                            |
| `each`                 | `each(readLine).where(...).arranged(...).form(...)` or a fold                                   |
| `.splicing`            | `form({ ...shape }).splicing(...formerUses)`                                                    |
| `is`                   | `is.lt`, `is.le`, `is.gt`, `is.ge`, and `is.among` comparisons                                  |

`now(variable)` is available only in a reaction's `where` stage, including an
endpoint stage's `.where(...)`. It opens one logic variable and binds it to the
instant stamped on the current causal flow's outermost occurrence. The clock is
read once when that flow opens, not once per use, so every reaction in the flow
observes the same instant. The outermost occurrence log and the reaction binding
use that one stamp rather than taking separate clock readings.

A caller cannot author this value. Registration rejects `now` in views and
standing-state formers, as a trigger or action input, and in `receive(...)`, just
as the boundary prevents a caller from authoring `requestId`. A concept that
needs the instant still declares it as an action input; composition supplies it:

A reaction writes `.where(now(instant))` and then passes `instant` to each action
declaring it, as `Expiring.schedule({ subject, expiresAt, now: instant })` does.

`.afterFlowSettles()` may follow `when(trigger)` or a completed stage. It may be
followed directly by `.then(step)` or by `.where(...conditions).then(step)`. On
an initial deferred stage, `.where(...)` also accepts one frame function,
subject to the ordinary portability restrictions. A chained deferred stage
accepts condition lines only; TypeScript rejects a frame function, and untyped
use fails while constructing the declaration. Registration separately rejects
a later deferred stage when its containing chain cannot lower to reactions.

| Consumer           | Result                                                       | Empty selection |
| ------------------ | ------------------------------------------------------------ | --------------- |
| `.form({ ... })`   | One record per row                                           | `[]`            |
| `.count()`         | Number of rows                                               | `0`             |
| `.first(value)`    | Value from the first selected row after optional arrangement | `null`          |
| `.distinct(value)` | First-seen distinct values                                   | `[]`            |

The TypeScript contract for `count` requires one non-union query reference and
its complete input mapping, with undeclared fields rejected recursively. A
union-typed query reference is rejected outright so the input argument cannot
select or mask one possible query; choose one concrete query before calling
`count`.

`QueryPromise` is `"one" | "optional" | "many"`.
When a query promise is available as a TypeScript literal, concept-set types
link `"one"` to a record return and `"optional"` or `"many"` to an array of
records. Runtime evaluation checks the same container and cardinality contract.
`Condition`, `ReadLine`, and `RelationView` name reusable declaration shapes.
View and former builders receive binding bags. Reading a property, including by
destructuring, declares a stable logic variable in that input, output, or
free-binding partition. Completed views and formers take one object-shaped input
mapping.

`compute(...)` binds any complete result to one variable. When the awaited
result is a record-shaped, non-array object, an output pattern may instead bind
or test several fields, including nested fields. TypeScript checks the pattern against the
computation's return type, and generated wire provenance follows each field's
return-type path.

A `form({ ... })` entry accepts a bound variable, another formed node, or
portable JSON literal data. Literal objects and arrays are copied into the
former IR and do not require a computation. Non-finite numbers, `undefined`,
class instances, functions, symbols, and cyclic values are not portable former
literals.

`.splicing(...uses)` merges one or more record-rooted former fragments into a
host record. Each variable referenced by a fragment input must already be bound;
literal inputs are accepted. Fragment keys must not collide with host or
earlier-fragment keys. A plain optional fragment drops the host row when absent;
`whether(...)` preserves the row and fills the fragment leaves with `null`.
Runtime evaluation checks each fragment's declared promise and faults if it
produces several rows. A fragment must be record-rooted; the host may be a record
form or an `each(...).form(...)` selection row.

See [Application design authoring](../guide/authoring.md),
[reaction semantics](semantics.md#reactions), and [views and
formers](semantics.md#views-and-formers).

## `assembly`

<!-- register:assembly:start -->

`ActionRefusal`, `Assembly`, `ConceptFloor`, `ConceptImplementation`, `ConceptRegistration`, `ConceptSetAssemblyOptions`, `ConcurrentReads`, `ExecutionLimits`, `FileLogSink`, `FiringRecord`, `ImplementationOverrides`, `Implementations`, `IntegrityFailureRecord`, `LogEntry`, `LogSink`, `Logging`, `OperationalEvent`, `OperationalObserver`, `OperationalResultClass`, `QueryCacheMode`, `ReactionFailureRecord`, `RawFaultReport`, `RawFaultReporter`, `RegisteredConcept`, `RegisteredConceptSet`, `RetentionPolicy`, `assemble`, `checkBatchedQuery`, `conceptFloor`, `conceptSet`, `registerConcept`

<!-- register:assembly:end -->

### Assembly construction

```ts
assemble(options: ConceptSetAssemblyOptions): Assembly
```

| `ConceptSetAssemblyOptions` field | Required    | Default / effect                                                                                                       |
| --------------------------------- | ----------- | ---------------------------------------------------------------------------------------------------------------------- |
| `conceptSet`                      | yes         | Registered application concept set                                                                                     |
| `composition`                     | yes         | Reactions, endpoints, views, and formers to register                                                                   |
| `initialize`                      | conditional | Constructor tuples; required when canonical classes need arguments and `instances` does not supply them                |
| `instances`                       | no          | Ready implementations by instance name; each overrides `initialize`; object identities must be distinct                |
| `logging`                         | no          | `Logging.OFF`; alternatives are `TRACE` and `VERBOSE`                                                                  |
| `retention`                       | no          | `{ window: 100 }`; accepts any valid `{ window: number }` or `"keepAll"`                                               |
| `queryCache`                      | no          | `"memoize"`; `"since-dispatch"` keeps running invocations' answers across later ones; `"none"` disables it             |
| `concurrentReads`                 | no          | (experimental) Rows read one after another; `{ rowsAtOnce, maxRowsAhead? }` reads a line's rows together, in row order |
| `groupBatchedQueries`             | no          | `true`; currently groups only with a query cache and `rowsAtOnce` above 1; `false` sends lists of one                  |
| `clock`                           | no          | System clock; called once when each causal flow opens to stamp its outermost occurrence and supply `now`               |
| `logSink`                         | no          | No external sink; `append` receives each validated, redacted entry and must return `undefined` synchronously           |
| `executionLimits`                 | no          | Unbounded profile; validates and enforces every `ExecutionLimits` field                                                |
| `observers`                       | no          | No operational observers                                                                                               |
| `rawFaultReporter`                | no          | No privileged raw action, interpreter, or endpoint-validator failure handoff                                           |
| `redaction`                       | no          | Universal sensitive-field patterns only                                                                                |

`RetentionPolicy` is `"keepAll" | { window: number }`. A retention window must
be a finite, non-negative integer. Window enforcement runs automatically only
after a causal flow settles. `{ window: 0 }` therefore allows an active flow to
complete before evicting it. The public assembly and engine surfaces expose no
manual prune operation.
Every assembly owns an internal occurrence index; `logSink` neither replaces it
nor restricts `retention`.

`ConcurrentReads` is `{ rowsAtOnce, maxRowsAhead? }`, both positive integers:
at most `rowsAtOnce` rows of one line or selection are read at once, and at
most `maxRowsAhead` rows (64 when unset) are started ahead across the assembly
(`concurrentReads` is experimental; see the
[support policy](../../../SUPPORT.md#stable-compatibility)). Each call of a
batched query receives a frozen list of inputs, copied as plain data. The engine
may group reads issued together into one call; it currently does so only with a
query cache and `concurrentReads.rowsAtOnce` above 1. With
`groupBatchedQueries: false`, each read calls the list form with a list of one.
See [ordering and state-read timing](semantics.md#ordering-and-state-read-timing)
and [batched queries](semantics.md#batched-queries).

`Assembly` exposes `concepts`, `invoker`, `publicInterface`, `beginDrain()`,
`whenIdle()`, and `form(fusedFormer)`. Drain closes root admission immediately;
both lifecycle promises resolve when accepted action, query, and former work
actually settles. With `concurrentReads`, they also wait for rows started ahead
to settle, including rows abandoned after a fault. `form(...)` resolves to the
formed runtime value; an optional record former contributes `null` to that
result.
`ActionRefusal` is the direct-action refusal result.
For a registered exception, it contains the specification code and sentence as
`detail`. The standard boundary refusal funnel exposes the code without that
detail.
`ConceptImplementation`, `Implementations`, and `ImplementationOverrides` name
complete or partial implementation maps. Assembled non-query actions are
asynchronous and conservatively resolve to their awaited result or an
`ActionRefusal`; underscore-prefixed queries resolve asynchronously to their
declared implementation answer.

Ordinary assembly rejects local closures, explicit `custom` operations, `$is`
object-identity patterns, raw transforms, and whole unlowered reactions before
returning an invoker or routes. Manual `advanced` engines retain these escapes.
Assembly recursively discovers tagged declarations in nested plain records and
module namespace objects. Reactions and endpoints use their dotted record path
as the registration name; views and formers retain the names supplied to their
constructors. Untagged, nullish, and nondeclaration leaves are ignored; assembly
does not call function leaves as composition factories.

`OperationalEvent` is the stable discriminated union for action settlement,
interpreter and integrity failure, invocation settlement, limit breach, and
drain state. `OperationalObserver` callbacks are synchronous bounded handoff:
the engine catches throws and never awaits returned work; exporters and network
I/O belong behind a host-owned queue. Events carry no action input or output.
`OperationalResultClass` names the safe result categories.
`RawFaultReport` is the privileged discriminated union for the original
`unknown` values thrown by actions, interpreter stages, and endpoint validators.
`RawFaultReporter` failures are isolated: a throw or rejected returned
promise-like value does not change the action or invocation result. Raw values
do not enter ordinary occurrence evidence, operational events, process logs, or
public framework errors. Restrict access to this reporter as for any other
sensitive host sink.

### Registration and floors

An ordinary application creates one registered concept-set object and passes
that object—not its `.concepts` property—to assembly. Every key is a selected
application instance name, and every value is the registered concept definition
that instance realizes:

```typescript
export const applicationConceptSet = conceptSet({
  Posting: posting,
  Commenting: commenting,
});

export const { concepts } = applicationConceptSet;

assemble({
  conceptSet: applicationConceptSet,
  composition,
});
```

`applicationConceptSet.concepts` contains typed concept declarations used while
writing composition. `applicationConceptSet.implementations(...)` constructs
concrete implementation maps, and `applicationConceptSet.computations` contains
the named computation references supplied to `conceptSet`. The complete
`applicationConceptSet` retains all three facets and the internal declaration
needed by assembly and tooling.

| API                 | Compact signature                                                 |
| ------------------- | ----------------------------------------------------------------- |
| `registerConcept`   | `registerConcept({ class, spec, refusals?, batched?, floors? })`  |
| `conceptSet`        | `conceptSet({ ...registeredConcepts }, computations?)`            |
| `conceptFloor`      | `conceptFloor(conceptSet, { name, instances, resources, close })` |
| `checkBatchedQuery` | `checkBatchedQuery(instance, query, sampleInputs)`                |

`ConceptRegistration`, `RegisteredConcept`, `RegisteredConceptSet`, and
`ConceptFloor` name those descriptors. Floor names must be non-empty, and each
supplied floor value must be a factory function. Each call to
`set.implementations(floor, context)` first verifies that the named floor is
complete, then calls its selected factory exactly once for every concept-set key.
Each factory receives that exact caller-supplied `context`, followed by that
key's application instance name; TypeScript requires the context to satisfy
every selected factory's first parameter. A second `implementations(...)` call
performs construction again. This context is separate from
`ConceptFloor.resources`.

A floor name is available through the typed `implementations(...)` overload only
when every selected registration supplies it. If an incomplete floor is
selected by bypassing that type restriction, selection fails before any factory
runs. The zero-argument `implementations()` form is available only when every
canonical class can be constructed without required arguments; each call
constructs one new object per selected key. Otherwise use a named floor.

Assembly itself does not always call floor factories. For each selected name,
`assemble` uses a supplied `instances` object first, otherwise constructs from
supplied `initialize` arguments, otherwise default-constructs the canonical
class. Within one assembly, two names cannot use the same raw implementation
object. This identity check is assembly-local: the same raw object may be used
in a separate assembly under a semantically compatible registration, which then has a
separate action queue and query cache. Incompatible metadata remains invalid because one
object cannot honor two conflicting contracts.
Separate objects are not proof of separate durable state. A persistent floor
factory should use its instance-name argument to select an explicit repository,
collection, schema, namespace, or equivalent resource when isolation is
required. Intentional resource sharing remains host configuration.

The optional second `conceptSet` argument supplies named pure computations.
The set exposes inferred references under `set.computations`. Compose raw
records before constructing one set; refs from separate concept sets cannot be
combined.

`batched` names queries the class implements in list form. Each such method
takes a list of inputs and returns one answer per input, in the same order;
compositions and callers of an assembled concept still ask it with one input
and get one answer, while code holding the raw class instance calls the list
form. `registerConcept` rejects a name the specification does not declare as a
query, and TypeScript accepts only the class's query names. `conceptSet`
rejects a name given twice and a batched method that destructures one input or
takes a `_` placeholder, and `assemble` rejects a selected implementation whose
batched method does so. Only `sync-engine check` verifies from the types that
the method takes a list; it also rejects a rest parameter. Batched names are
written in the `registerConcept(...)` call and carried by its inferred type;
input names come from the specification. `ConceptRegistration<C>` and
`RegisteredConcept<C>` written out name no batched queries, so a registration
that names some does not compile against them. `Assembly<T, Batched>` works the
same way: its second parameter maps each concept-set key to the query names
batched for it, and `concepts` types those queries as taking one input. It
defaults to no names, so a written-out `Assembly<T>` types a batched query in
its class's list form; keep the inferred type of `assemble(...)`. Readers of the
concept set's refs and of an assembled concept ask a batched query with one
input; a query that takes a list without being named keeps its own types.
`checkBatchedQuery` checks a list form's law on the raw instance with sample
inputs: each answer equals the answer for that input alone, in order, reversed,
and with duplicates, no answer is missing, an empty list answers an empty
list, and answers to different inputs share no objects. It passes the list
frozen, as the engine does, and rejects with what differed. It compares
records, arrays, dates, maps, sets, and binary data, and fails on any other
object, such as a class instance or a promise. Execution semantics for batched
queries are in [semantics](semantics.md#batched-queries).

`conceptFloor` validates a complete implementation map and returns the supplied
descriptor. Assembly does not install, own, or call the floor's `close()`
method. The host owns floor selection and lifecycle.

`RegisteredConcept.specification` is the machine-readable version-1
`ConceptSpec` extracted from the strict ordered Purpose, Principle, Types, State,
Actions, and Queries sections. It retains external declarations, normalized full
State text, structured action branches and outcomes, query choices, and source
locations. Config-based checking compares
member, input, action-result, query-row, return-name, optionality, and refusal
shapes with resolvable TypeScript source. It also uses the SSF-owned names, aliases
included, and joined subset identifiers to prove qualified external-binding targets.
Query choices are enforced when a reaction, view, or former evaluates a query. Opaque invariant/prose semantics are not
compared with class fields, floor implementations, databases, or storage.

### Occurrence index and log sinks

Every engine owns a nonreplaceable process-local occurrence index for reaction
matching and retained inspection, governed by `RetentionPolicy`.

`LogSink.append(entry)` is the synchronous audit extension point. The engine
validates the entry, redacts engine-created mappings, calls the sink with a
structural snapshot, then folds it into the internal index. Arrays and plain records are copied and frozen.
Invocation concept and action fields become frozen, name-preserving
representatives. `Date` values are copied.
Opaque leaves such as class instances, `Map`, `Set`, and functions
retain their runtime representation and identity. The snapshot does not
recursively freeze opaque leaves. The sink must treat opaque leaves as read-only
sensitive values; structural readonly types do not make those leaves immutable.
`append` must return `undefined` synchronously. A throw or any other return
value, including a promise or structural thenable, fails the append before the
fold. An invocation append failure can prevent the action body from running. An
outcome append failure can occur after the body has changed concept state; the
engine does not roll that state back. A deferred firing append can fail after its
consequence changed state. If recording the resulting reaction failure also
fails, settlement aborts and the outer action call rejects; active-flow matching
state is still cleared, and concept state is not rolled back.

`FileLogSink(path)` implements `LogSink` with one append-only JSON audit
projection per entry. Concept instances and action functions are represented by
name. Before writing, it independently applies the default field-name redaction
policy to invocation inputs, outcomes, faults, and firing bindings, including
entries passed directly to `append`. It never reads or replays existing lines,
and retention never rewrites the file. `FileLogSink` has no close API. A custom
sink remains responsible for its own durability, concurrency, retry, and
resource lifecycle; the host closes custom resources after drain through an
application-defined API.

`LogEntry`, `FiringRecord`, `ReactionFailureRecord`, and
`IntegrityFailureRecord` name the corresponding contracts. Persistence,
eviction, redaction, sink failure, and restart limits are normative in
[Execution semantics](semantics.md#logs-concept-implementations-and-restart).
The [persistence and restart recipe](../guide/persistence-recovery.md#persistence-restart-and-recovery)
shows separate concept-state and occurrence files plus explicit derived-state
recovery.

## `boundary`

<!-- register:boundary:start -->

`ApplicationInterface`, `TransportBinding`, `WireProjectionFacts`, `EndpointDef`, `EndpointOptions`, `EndpointValidator`, `EndpointValidators`, `ExecutionLimits`, `FrameworkErrorCode`, `Gateway`, `GatewayOptions`, `GatewayTarget`, `InputContractDecl`, `InvocationResult`, `InvokeOptions`, `Invoker`, `OperationalEvent`, `OperationalObserver`, `OperationalResultClass`, `ValidationResult`, `assertPortableRoutePath`, `bindTransport`, `createGateway`, `endpoint`, `receive`, `respond`, `serializeJsonValue`

<!-- register:boundary:end -->

### Endpoints

| API        | Compact signature                                                                        |
| ---------- | ---------------------------------------------------------------------------------------- |
| `endpoint` | `endpoint(path, vars => receive(input)...then(respond(body)), { input?, validators? }?)` |
| `receive`  | `receive(input?)`                                                                        |
| `respond`  | `respond(body?)`                                                                         |

`EndpointDef`, `EndpointOptions`, and `InputContractDecl` name the declaration
and optional runtime outer-shape contract. `EndpointValidator`,
`EndpointValidators`, and `ValidationResult` define schema-library-neutral
input, successful-output, and domain-error checks. The domain-error validator
receives exactly the value of the authored response's top-level `error` field.

| Type                 | Shape                                                    |
| -------------------- | -------------------------------------------------------- |
| `ValidationResult`   | `{ ok: true } \| { ok: false; detail?: string }`         |
| `EndpointValidator`  | `(value: unknown) => ValidationResult`                   |
| `EndpointValidators` | Optional `input`, `output`, and `domainError` validators |

[Execution semantics](semantics.md#sibling-paths-and-endpoint-settlement)
defines endpoint settlement. A stage may state `.afterFlowSettles()` to form its response at a
settlement frontier. Add conditions that identify any terminal state the
endpoint requires; see [deferred triggers and settlement
frontiers](semantics.md#deferred-triggers-and-settlement-frontiers).

Endpoint paths must be canonical portable absolute URL pathnames. Queries,
fragments, scheme-relative paths, dot-segment normalization, malformed percent
escapes, literal spaces, and literal Unicode are rejected; the declared spelling
must survive WHATWG pathname handling unchanged. See [Correlation and route
paths](semantics.md#correlation-and-route-paths). `receive(...)` cannot author
the framework-owned `path` or `requestId` fields. `respond(...)` cannot author
`requestId` or `errorKind`.

Applications supply endpoint validators explicitly. Generated types and concept
State notation have no runtime schema semantics. Validators must return a
`ValidationResult` synchronously; a promise-like result fails validation.

| `InputContractDecl` field | Default / effect                                 |
| ------------------------- | ------------------------------------------------ |
| `required`                | `[]`; missing listed keys return `INVALID_INPUT` |
| `defaults`                | `{}`; fills listed keys only when absent         |

Without an explicit contract, assembly derives required keys from portable
endpoint IR: it intersects the non-reserved keys mentioned by every exported
`receive(...)` pattern for the path. A key outside that intersection cannot be
required because at least one path alternative does not mention it. An
executable-only endpoint has no derived contract. An explicit contract is
authoritative and replaces the derived contract; it does not merge with it. At
most one endpoint declaration may supply an explicit contract for a given path.
Assembly rejects an explicit contract when omitting its optional keys cannot
match any receive alternative after declared defaults are applied.
Admission checks required keys before shallowly applying defaults, then invokes
the application ask. An invalid successful output records an integrity failure
and returns opaque `INTERNAL_ERROR`. An invalid domain-error value records
`invalid-domain-error` integrity evidence and also returns opaque
`INTERNAL_ERROR`. A thrown validator fails closed and reaches
`rawFaultReporter`, when configured, as an unsanitized `endpoint-validator`
report. An input-validator throw returns `INVALID_INPUT` before the boundary ask;
output and domain-error integrity evidence retain only the `ValidatorFault`
class. A path may declare each validator at most once.

### Gateway and invocation

```ts
createGateway<Contract>(options: GatewayOptions): Gateway<Contract>
invoker.invoke(path, input, options?: InvokeOptions): Promise<InvocationResult>
```

| `GatewayOptions` field | Required | Default / effect                                         |
| ---------------------- | -------- | -------------------------------------------------------- |
| `application`          | yes      | `GatewayTarget` exposing `invoker` and `publicInterface` |
| `executionLimits`      | no       | Unbounded gateway admission and caller deadline          |
| `observers`            | no       | Drain, limit, and final public-call settlement events    |

| `InvokeOptions` field | Default / effect                                                                    |
| --------------------- | ----------------------------------------------------------------------------------- |
| `signal`              | No signal; an abort ends the wait with `ABORTED`                                    |
| `timeoutMs`           | `30_000` without `executionLimits`; otherwise `maxRequestDurationMs`                |
| `correlationId`       | The generated request id; supplied values cross gateway and application observation |

`ExecutionLimits` requires positive finite integers for active root flows,
pending requests, actions and firings per flow, rows per evaluation, and the
maximum caller deadline. `maxRequestDurationMs` must not exceed the reliable
platform timer maximum of 2,147,483,647 ms. Overload and drain return
`UNAVAILABLE`. `Gateway` also exposes `beginDrain()` and `whenIdle()` and
includes the target assembly's lifecycle when that target supplies it.

An explicit `timeoutMs` must be a positive finite integer no greater than
2,147,483,647 ms. When execution limits are configured, it must also not exceed
the layer's maximum request duration. An invalid value returns `INVALID_INPUT`
before work is recorded. Gateway and application invokers apply the option as
separate durations; it is not one absolute deadline shared by both layers.

The gateway decorates the target application's `Invoker` and uses the target's
reaction engine. Observers
receive gateway limit and drain events plus exactly one `invocation-settled`
event for each public `invoke` call after the final result is known. That event uses the
requested application route and effective correlation id, includes the final
result class and applicable framework code, measures through the final
caller-visible result, and may omit `flow`. Accepted sibling work can continue
afterward; use `whenIdle()` to observe flow quiescence.

`Gateway`, `GatewayTarget`, `Invoker`, and `InvocationResult` name these
contracts. Timeout and abort stop waiting but do
not cancel forwarded application work. A fault-free unanswered endpoint reaches
`TIMED_OUT`; an unanswered flow with a recorded interpreter failure settles
promptly as opaque `INTERNAL_ERROR`. See [Failures between action
asks](semantics.md#failures-between-action-asks) and
[Cancellation](semantics.md#cancellation).

### Transport binding

| API                       | Compact signature / role                                    |
| ------------------------- | ----------------------------------------------------------- |
| `bindTransport`           | `bindTransport({ application, gateway }): TransportBinding` |
| `assertPortableRoutePath` | Rejects noncanonical public route spellings                 |
| `serializeJsonValue`      | Shared JSON serialization for a transport adapter           |

`bindTransport(...)` verifies that a gateway belongs to the assembly and returns
a narrowed invoker plus frozen route and logical-wire facts, without reaction
state, mutable registries, or lifecycle controls. Same-version duplicate core
packages retain global identity behavior. Custom adapters need no first-party
transport package.

`WireProjectionFacts` is the immutable route and logical-wire input passed to a
generated projection. It remains transport-neutral; core owns strict leaf
checks, concept-set anchoring, rendering, provenance, and atomic artifact
writes.

### Framework errors

`FrameworkErrorCode` is the stable core value object; its value union names the
core boundary and client framework failures. A transport may add its own error
union. Controlled admission details may accompany an error, but exception text
from an unknown failure is omitted.

| Code              | Ordinary source                                              |
| ----------------- | ------------------------------------------------------------ |
| `INVALID_INPUT`   | Shape, contract, option, or input validation                 |
| `NOT_FOUND`       | Unknown logical route                                        |
| `UNAVAILABLE`     | Overload or draining admission                               |
| `TIMED_OUT`       | Invocation or transport wait expired                         |
| `ABORTED`         | Invocation or client signal aborted                          |
| `INTERNAL_ERROR`  | Application, framework, validation, or interpreter fault     |
| `TRANSPORT_ERROR` | Forwarding, transport, or client-response validation failure |
| `UNKNOWN_ERROR`   | Unclassified framework envelope                              |

## `client`

<!-- register:client:start -->

`Client`, `ClientCallOptions`, `ClientError`, `ClientOptions`, `ClientRequest`, `ClientResponseValidator`, `ClientTransport`, `ContractShape`, `DomainErrorValue`, `createClient`, `createLocalClient`

<!-- register:client:end -->

### Constructors

| API                 | Compact signature                                                                                                          |
| ------------------- | -------------------------------------------------------------------------------------------------------------------------- |
| `createLocalClient` | `createLocalClient<Contract>({ invoker, validateResponse? }): Client<Contract>`                                            |
| `createClient`      | `createClient<Contract, TransportError = ClientError>({ transport, validateResponse? }): Client<Contract, TransportError>` |

`ClientOptions.transport` and `createLocalClient`'s `invoker` are required.
The optional synchronous `validateResponse(value, { path })` checks each complete
untrusted transport result. A
`{ ok: false }` result, throw, or promise-like result resolves to
`{ error: "TRANSPORT_ERROR" }`; an accepted value is returned unchanged.
`ClientTransport` and `ClientRequest` name the extension contract. Every
endpoint call accepts an optional second `ClientCallOptions` argument:

| Field           | Transport request effect                                                        |
| --------------- | ------------------------------------------------------------------------------- |
| `signal`        | Carries caller abort; cancellation behavior depends on the selected transport   |
| `timeoutMs`     | Carries a transport-local timeout; the core client does not interpret the value |
| `correlationId` | Carries a trace token when the selected transport supports correlation          |

`ClientRequest` carries the same three optional fields. None promises rollback
or cancellation of accepted server work.
A `Client<Contract>` supports grouped access such as
`client.rooms.get(input)` and indexed access such as
`client["/rooms/get"]`, followed by the input call. A path rooted at `then` or
containing an `inspect`, `toJSON`, `toString`, or `valueOf` segment remains
available through indexed access only; Promise assimilation, serialization,
inspection, and primitive coercion therefore cannot invoke an endpoint
implicitly.

`ContractShape` is the path-to-input/output/error record accepted by every
constructor. `ClientError` is `{ error: FrameworkErrorCode; detail?:
string }`; `DomainErrorValue` extracts a generated route's domain error value.
Calls resolve handled transport failures as error envelopes. JSON projection
and error delivery are normative in
[Execution semantics](semantics.md#boundary-gateway-and-client).

`createClient` replaces a nullish input with `{}`. A transport throw or rejected
promise resolves as `{ error: "TRANSPORT_ERROR" }`. A transport-specific error
type can be supplied as the second generic parameter. This does not weaken the
generated endpoint input and output types.

## `tooling`

<!-- register:tooling:start -->

`ActionTriggerIR`, `AppIR`, `ApplicationDiagnostic`, `ApplicationManifestV1`, `ChannelTriggerIR`, `ComputationInventoryIR`, `ConceptImplementationProvenanceIR`, `ConceptInventoryIR`, `ConceptSpecDiagnostic`, `ConceptSpecDiagnosticCode`, `ConceptSpecParseResult`, `ConceptSpecificationIR`, `ConsequenceIR`, `DiagnosticCode`, `DiagnosticSeverity`, `FormerIR`, `FormerNodeIR`, `FormerSourceIR`, `GeneratedApplication`, `ManifestEndpointV1`, `ObservedOccurrence`, `PatternIR`, `PlannedWireProjection`, `ProjectionProvenance`, `ProjectionRenderOptions`, `QueryRefIR`, `ReactionIR`, `SpecificationActionIR`, `SpecificationExternalTypeIR`, `SpecificationFieldIR`, `SpecificationLocationIR`, `SpecificationQueryIR`, `SpecificationRefusalIR`, `SpecificationResultIR`, `SpecificationStateIR`, `SpecificationTypeIR`, `SpliceIR`, `TriggerIR`, `UnloweredIR`, `ValueIR`, `ViewIR`, `ViewOpIR`, `WhereOpIR`, `WireContractsIR`, `WireEndpoint`, `WireOptions`, `WireProjection`, `WireProjectionResult`, `WireRenderOptions`, `WireType`, `applicationDiagnostics`, `applicationManifest`, `applicationManifestDigest`, `diagnosticsFail`, `inspectAssembly`, `parseApplicationManifest`, `parseConceptSpecification`, `renderApp`, `renderApplicationManifest`, `renderInputContracts`, `renderReaction`, `renderWireTypes`, `validateApplicationManifest`, `wireContracts`

<!-- register:tooling:end -->

### Inspection and rendering

| API                           | Compact signature                                                            |
| ----------------------------- | ---------------------------------------------------------------------------- |
| `inspectAssembly`             | `inspectAssembly(assembly)`                                                  |
| `renderApp`                   | `renderApp({ title, concepts, app }): string`                                |
| `renderReaction`              | `renderReaction(reaction): string`                                           |
| `renderInputContracts`        | `renderInputContracts(contracts): string`                                    |
| `wireContracts`               | `wireContracts(app, options?: WireOptions): WireContractsIR`                 |
| `renderWireTypes`             | `renderWireTypes(wire, moduleName? \| options?): string`                     |
| `applicationManifest`         | `applicationManifest(assembly): ApplicationManifestV1`                       |
| `applicationManifestDigest`   | `applicationManifestDigest(manifest): string`                                |
| `parseApplicationManifest`    | `parseApplicationManifest(source): ApplicationManifestV1`                    |
| `renderApplicationManifest`   | `renderApplicationManifest(manifest): string`                                |
| `validateApplicationManifest` | `validateApplicationManifest(value): asserts value is ApplicationManifestV1` |
| `applicationDiagnostics`      | `applicationDiagnostics(app, endpoints, wire)`                               |
| `diagnosticsFail`             | `diagnosticsFail(diagnostics, "errors" \| "warnings"?)`                      |
| `parseConceptSpecification`   | `parseConceptSpecification(markdown): ConceptSpecParseResult`                |

`AppIR`, `ReactionIR`, `ViewIR`, `FormerIR`, `ConceptInventoryIR`, and
`ObservedOccurrence` name inspected data. `ObservedOccurrence` contains the
concept, action, optional `by`, output, and outcome summary; it omits input,
action id, flow, and timestamp. Inspection reports only evidence retained by
the internal occurrence index and applies redaction again. `WireContractsIR`, `WireEndpoint`, and
`WireType` name derived wire data. A `WireType` reference origin uses concept,
member, and path for action/query signatures. The `computation-input` and
`computation-output` origins instead use computation and path to identify the
registered vocabulary computation's `fn` parameter or awaited result.
`WireEndpoint.inputAdmissionError` preserves whether framework input admission
contributed `INVALID_INPUT`, so production projection remains distinct from a
registered domain refusal using the same code.

`ReactionIR.deferred` is optional. When `true`, the engine arms the trigger match
when the trigger lands, then qualifies it and dispatches surviving bindings at
settlement frontiers. It re-evaluates `where` at each frontier until the match
qualifies or the flow finalizes. When absent, qualification happens where the
trigger lands. Imported IR with another value is rejected. Standalone deferred
`ReactionIR` must be consumed by a package version that recognizes the field;
use the same package version to produce and consume standalone IR. The
versioned manifest protects application IR carried inside a manifest from
incompatible tooling.

The application manifest has format `sync-engine.application-manifest`, version
`1`, and is canonical JSON-round-trippable application data. Stable v1 fixes
this schema; incompatible structural or semantic changes require a new integer
format version and new public type names. Incompatible earlier beta shapes are
rejected without upconversion. It
contains executable application and wire facts plus structured concept
contracts, full State text, authored definition/instance declarations and external
bindings, SSF-derived definition-owned type inventories, resolved application types,
computation signatures, registered design source locations, normalized-source digests, implementation provenance, validators, and diagnostics. It excludes
runtime functions, constructor arguments, resources, object identity,
occurrences, timestamps, and other runtime state.

`ComputationInventoryIR` contains every installed computation, including all
five standard computations and unused vocabulary computations. `source`
distinguishes `standard` from `vocabulary`; `inputs` is present only when the
function's top-level destructuring can be read conservatively. The manifest
sorts entries by name and never carries the function itself.

`ConceptImplementationProvenanceIR` separates a concept set's canonical
class from the implementation selected by assembly. `RequestBoundary` is
core-owned and selected through `core`; an application concept set cannot reuse
that name, and authored instance completeness excludes it. Application concepts
report `default`, `initialize`, or `instances`. Constructor names are descriptive and omitted for anonymous or
structural `Object` values; selected constructor names and `floor` can occur only
with `instances`. A floor is omitted when provenance is ambiguous. Concept
member roles, query cardinalities, and refusal semantics come from the canonical
vocabulary declaration rather than a replacement instance.
`applicationManifestDigest(...)` recomputes the digest while ignoring the
supplied `digest` field. `validateApplicationManifest(...)` treats its input as untrusted data: it
checks the complete top-level version-1 shape, the nested IR needed by tooling,
inventory uniqueness and cross-field consistency, independently rederives persisted
owned types and subset binding targets from each included specification, endpoint,
input-contract, and logical-wire path agreement, plain JSON portability, and exact canonical digest
equality. Previous versions are rejected without upconversion.
Failures identify the offending `$` path. `parseApplicationManifest(...)`
performs the same checks after JSON parsing and returns data in canonical record-key
order; neither function imports application code or a manifest-producing config.
`parseConceptSpecification(...)` exposes the same structured, source-located
contract used by registration. It returns a `ConceptSpecParseResult`: a valid input has
its `specification` and no diagnostics; an invalid input has no specification and every
coded, line-and-column diagnostic found during parsing. It enforces the exact section
order, parses external declarations and structured action/query choices, and retains full
State text. Private config and form-check tooling separately parses bounded SSF structure
and its aliases,
checks the subset graph and local namespaces, and inventories owned type names. Field
refinements and `Rule:` prose remain open authored contracts; neither layer turns
authored types into runtime schemas.

Each concept inventory may carry a `sync-engine.concept-specification`
version-1 subtree with the definition name, external types, normalized full
State text, structured actions and queries, refusals, and source locations. Selected application inventories separately retain authored instance
declarations, definition names, external bindings, and their source locations.
`renderApplicationManifest` emits canonical JSON with ordinal record-key order
and a final newline. Named collections use stable order while authored reaction,
view-alternative, and former-node sequences retain semantics.

`ApplicationDiagnostic`, `DiagnosticCode`, and `DiagnosticSeverity` define the
advisory surface. `diagnosticsFail` fails on errors by default and can promote
warnings; informational diagnostics remain advisory.
Endpoint diagnostics trace causal `by` provenance to attribute an eventual
response to its request path. Only a response that uses the traced request
identifier contributes to a proof. Direct response paths and recognized total
action chains contribute to overlap proof; chain overlaps name their root
reactions. Coverage recognizes linear action chains whose successful postures
have exact inputs, empty output patterns, and only guaranteed ancestor replays;
the standard boundary funnels cover refusal and fault outcomes. Deferred stages
remain eligible. Proofs concern portable JSON-shaped boundary values, not live
object identity or accessor behavior. Coverage does not prove that an action or
read eventually settles. On direct paths, the analyzer recognizes canonical
`receive(...)` shapes, disjoint literal request alternatives, non-dropping
`whether` lines, and fresh computations.
`ENDPOINT_PATH_OVERLAP` reports bounded potential overlaps such as duplicate
complete guards, an unconditional answer beside a conditional answer, or a bare
existence branch that subsumes a more specific read. It does not prove that a
conditional guard is inhabited. `MISSING_ENDPOINT_FALLBACK`
means no non-dropping total answer path was recognized; it does not imply that
an unconditional sibling would be a safe ordered fallback. Coverage analysis
leaves complementary state reads unproved because siblings observe separate
state snapshots. The analysis is conservative and does not prove arbitrary
view, computation, validator, action-outcome, or concurrent-state logic.

The structural argument consumed by `renderApp` has `title: string`,
`concepts: ConceptInventoryIR[]`, and `app: AppIR`. The package does not export
a separate public name for that aggregate argument type.

| `WireOptions` field | Default                     |
| ------------------- | --------------------------- |
| `boundary.concept`  | `"RequestBoundary"`         |
| `boundary.request`  | `"request"`                 |
| `boundary.respond`  | `"respond"`                 |
| `contracts`         | No declared input contracts |
| `inventories`       | No concept inventories      |

| `WireRenderOptions` field | Default / effect                                                        |
| ------------------------- | ----------------------------------------------------------------------- |
| `moduleName`              | `"WireContracts"`                                                       |
| `banner`                  | Two-line core generator banner; a supplied string replaces it           |
| `conceptSet`              | No type anchor; `{ from, export }` enables signature references         |
| `strictLeaves`            | `false`; `true` requires an anchor and rejects unresolved `Json` leaves |
| `appWideErrorName`        | `"AppWideError"`                                                        |
| `preamble`                | `true`; set `false` when appending another contract to one module       |
| `sharedWires`             | `[]`; later contracts whose required helpers this preamble must emit    |

A render with `preamble: false` emits no imports or shared helper types. The
earlier render that emits the module preamble must receive every later
`preamble: false` contract in `sharedWires`; otherwise `renderWireTypes` can omit
a helper alias used by a later contract.

### Generated descriptor

The `sync-engine artifacts` command reads the default export of the
application-owned `generated.config.ts`. `GeneratedApplication` names the
descriptor type exported from `/tooling`.

| Field                 | Required | Default                                                            |
| --------------------- | -------- | ------------------------------------------------------------------ |
| `assemble`            | yes      | Synchronous function that returns the application assembly         |
| `title`               | yes      | Application title used to derive names                             |
| `close`               | no       | Runs after the generated assembly drains                           |
| `directory`           | no       | `new URL("./generated/", configUrl)`                               |
| `specification`       | no       | Slugged title plus `.md`                                           |
| `specificationBanner` | no       | Generated-from comment followed by mandatory provenance            |
| `wire`                | no       | `"wire.ts"`                                                        |
| `wireName`            | no       | Pascal-cased title plus `Wire`                                     |
| `wireBanner`          | no       | Exact package/version generator banner                             |
| `design.version`      | yes      | Must be `1`                                                        |
| `design.documents`    | yes      | Local design URLs; may contain `types` fences or be empty          |
| `conceptSet`          | no       | Source anchor; defaults to `src/concepts.ts#applicationConceptSet` |
| `projections`         | no       | Ordered transport-specific projections                             |

The default specification banner consists of these comments:

```text
<!-- Generated from the <title> assembly. Do not edit. -->
<!-- Manifest producer: @mit-sdg/sync-engine@<manifest-version>; concept specification: sync-engine.concept-specification@1; renderer: @mit-sdg/sync-engine@<renderer-version>. -->
```

A custom specification banner replaces the first comment but still receives
the mandatory provenance comment. The default wire banner is
`// Generated by @mit-sdg/sync-engine@<version> from the <title> assembly. Do not edit.`
A custom wire banner receives a second mandatory generator line. Artifact
generation always uses the concept-set anchor with strict leaves. Every
`WireProjection` receives frozen `WireProjectionFacts` and returns a named
`WireContractsIR`; core selects the shared preamble, rendering options, ordering,
strict-leaf checks, and provenance. A projection list can be empty or contain
multiple transport contracts in one wire module. `projections` must be an array,
and each entry must provide `project(facts)`. The logical wire name, projected
wire names, app-wide error names, `Json`, and generated concept-set helper names
must be distinct TypeScript identifiers. Projection provenance must contain a
nonblank package name and a valid SemVer version. Projector versions are
not restricted to 1.x. Artifact planning separately requires the manifest's
core generator identity to name `@mit-sdg/sync-engine` at a 1.x version;
generator and projector provenance may use prerelease versions. Core evaluates
projections in declaration order and rejects any projection or naming failure
before an artifact command compares or writes files. The
[application authoring guide](../guide/authoring.md#7-check-and-generate)
shows the application-owned command path; [Generated wire](semantics.md#generated-wire)
defines derivation guarantees.

## `advanced`

<!-- register:advanced:start -->

`Engine`, `EngineObserver`, `EngineOptions`, `LogEvent`, `Refuse`, `VocabularyAssemblyOptions`, `createEngine`, `custom`, `faulted`, `vocabulary`

<!-- register:advanced:end -->

Use `/advanced` only for low-level declarations, manual engine construction, or explicit escape hatches.
It follows the same stable compatibility policy as other public subpaths.

| API                         | Compact signature / role                             |
| --------------------------- | ---------------------------------------------------- |
| `createEngine`              | `createEngine(options?: EngineOptions): Engine`      |
| `vocabulary`                | `vocabulary({ concepts, computations? })`            |
| `VocabularyAssemblyOptions` | Direct-vocabulary option type accepted by `assemble` |
| `custom`                    | `custom(fn, inputs, outputs)`                        |
| `faulted`                   | `faulted(pattern, { by?, except?, exceptBy? }?)`     |

`vocabulary` is the low-level declaration API for callers that deliberately do
not use registered specifications or implementation floors. Concept entries are
either a concept class or `{ class, spec?, purpose?, principle?, queries?,
outcomes?, refusals?, batched? }`. Ordinary config-based applications use `conceptSet`
from `/assembly`, which creates the executable declaration internally. A direct
vocabulary can still be passed to `assemble` through the advanced
`VocabularyAssemblyOptions` alternative. `batched` takes effect only in
`assemble`: an engine from `createEngine` calls a batched query's method with the one input as
asked, not with a list, so instrument a batched class only through `assemble`.

`Engine`, `EngineObserver`, and `LogEvent` name manual interpreter and
observation contracts. `Refuse` is the low-level refusal marker. Its `message`
becomes the refusal's `error` field and takes precedence over an `error` field in
its optional data.
`EngineOptions` accepts `retention` and `logSink`; the default retention policy
is `"keepAll"`. The engine still owns its internal occurrence index. The optional
sink receives a synchronous audit copy and must return `undefined` from each
`append` call.

A manually created engine accepts an undeclared `Refuse` code as a refusal. It
warns when an explicit refusal contract omits that code. Ordinary
`assemble(...)` is closed instead: an undeclared advanced refusal is recorded as
a fault, and an unanswered endpoint settles as opaque `INTERNAL_ERROR`. The
advanced pieces do not install the
ordinary assembly's quiescent interpreter-failure settlement policy. Standard
assembly behavior is normative under [Failures between action
asks](semantics.md#failures-between-action-asks) and
[Cancellation](semantics.md#cancellation).
