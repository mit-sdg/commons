# Concept specification format

A concept specification is the reusable, concept-local contract passed as
Markdown text to `registerConcept`. It has a strict section order and a
TypeScript-independent version-1 representation. The specification defines a
concept definition; an application may instantiate that definition more than
once under different concept-set keys.

Application composition, concrete application types, concept instance
inventories and bindings, typed design links, and computations do not belong in
a concept specification. They belong in
[registered application design](../guide/authoring.md#6-register-explicit-design-urls).

For a new application, put one definition per
`design/concepts/DefinitionName.md`. This is the recommended authoring layout, not a
path restriction: registration follows the statically resolvable Markdown import.
Before implementation exists, parse explicit draft files with:

```sh
sync-engine check-design design/concepts/*.md
```

This command loads no application configuration or TypeScript source, writes nothing,
and reports authored-design form failures along with advice that does not fail the check;
it also accepts composition and
application-types documents in the same invocation. Config-based `sync-engine check` adds
registration provenance and TypeScript agreement after implementation.

## Document grammar

A specification has exactly one H1 followed by exactly these H2 sections, once
each and in this order:

```text
# DefinitionName

## Purpose
## Principle
## Types
## State
## Actions
## Queries
```

The H1 is the concept-definition name, not an application instance name. Author it as
a gerund naming the mechanism, such as `Tasking`, `Noting`, or `Authenticating`.
Unknown, missing, reordered, or duplicate H2 sections are rejected. Subsection
headings are also rejected: the six H2 sections are the complete document
outline. `Purpose` and `Principle` must contain nonempty prose and no fenced
blocks.

`Types`, `State`, `Actions`, and `Queries` contain only their one matching fence and
no surrounding Markdown. Invariant prose goes inside the `state` fence on a `Rule:`
line rather than after it. Application design links and `endpoints` or `computations`
fences are rejected anywhere in a concept specification.

## Complete example

````md
# Noting

## Purpose

Keep short notes for later retrieval.

## Principle

A person writes a note and reads it by its identifier. After the person
discards the note, another discard is refused because the note no longer
exists.

## Types

```types
external Person
  The person who authors a note.
```

## State

```state
a set of Notes with
  an author Person
  a text String
```

## Actions

```actions
write(author: Person, text: String) : returns (note: Note)
  where true
  then
    add a new note with author and text
    returns note

discard(note: Note) : returns (note: Note)
  where note is in Notes
  then
    remove note
    returns note
  where note is not in Notes
  then
    refuses NOTE_NOT_FOUND "There is no such note."
```

## Queries

```queries
_get(note: Note) : optional (author: Person, text: String)
  Returns no row when the note is not in Notes.
```
````

## `Types`

`Types` contains exactly one `types` fence. The fence may be empty. Version 1
accepts external parameters, concept-local enumerations, and opaque local types:

```types
external User
  The person who authors a comment.

Status is DRAFT or PUBLISHED
  The lifecycle states a publication may occupy.

opaque Secret
  A verifier whose representation belongs to the implementation.
```

The declaration grammar is:

```text
external Name
Name is VALUE or VALUE [or VALUE ...]
opaque Name
  optional explanation, which may continue on later indented lines
```

An external type is an opaque parameter supplied by each application that uses
the concept. An enumeration declares two or more uppercase values. An opaque local type
makes an intentionally unspecified representation explicit. Explanations are retained as
documentation. Concrete types and bindings are application design, not concept-local
declarations. Give every declared type the uppercase type-name form SSF uses, and do not
reuse the name of an SSF primitive. Write the primitive itself rather than declaring a
new name for it, and state narrowing constraints where they are enforced.

Every State field and every named type in an action or query signature resolves to a
concept-owned identity, an external parameter, a concept-local enumeration or opaque
type, or an SSF primitive; a State field may also name a declared subset. An unresolved name fails with `SSF_UNDECLARED_TYPE`,
whether it appears in a State field or a signature, and the check descends into nested
type arguments and unions. Owned, external, concept-local, and primitive names share one
namespace, so a Types declaration may not shadow a primitive or a State declaration. Version 1 parses type-expression shape without
claiming semantic equivalence with an implementation language.

## `State`

`State` contains exactly one `state` fence and no surrounding Markdown. The concept
parser normalizes and retains the fence's full contents in concept-specification IR and
application manifests. Private tooling also parses a bounded structural view for form
checks and owned-name resolution; that view is not part of the public
concept-specification IR.

Authors must use Simple State Form (SSF), defined by the canonical
[SSF language reference](https://github.com/mit-sdg/sync-engine/blob/main/packages/ssf/README.md).
The parser recognizes set, sequence, singleton, subset, alias, and field declarations
together with their multiplicities, identifiers, articles, uniqueness constraints, and
subset graph. Declared names are taken as written, and a field written without a name,
such as `an Author` or `a Verified User`, is named for its type: `author`, `verifiedUser`.

A plain top-level set, such as `a set of Users with a reputation Number`, contains every
individual of its type in the concept's state, and each of them has its fields. When its
type is the plural of an external type, as beside `external User`, the set holds
individuals of that external type instead of introducing identities, and means the same
thing. A subset qualifies its parent set: `a set of Verified Users`, `a set of Trusted
Verified Users`, or `a Root Folder`. A singleton uses just `a Type` or `an Type`, with
exactly one member; both articles are accepted. The old `element` keyword is rejected
with a repair that removes it. A top-level line declares the singleton; an indented
line with the same spelling declares a field. A subset is a type in State, so `a sponsor
Verified User` holds only Verified Users; action and query signatures take the parent
type and state membership in a condition, such as `where sponsor is in Verified Users`.

Two spellings of one owned type, such as `Note` in an operation signature and `Notes` in
the declaration, are joined when they form a singular and plural pair; an authored plural
of an external type joins that type the same way. Irregular pairs such as `Mouse`/`Mice`
and `Person`/`People` join too. Both spellings have to be authored, and the pair has to
be unambiguous on both sides; where it is not, the two names stay separate and the check
reports advice. `alias Alias for Target` states a synonym directly. An alias takes
precedence over a joined pair, targets a top-level declaration the concept owns rather
than another alias, a subset, or a set of an external type, and may appear before or
after its target. Subset parents are likewise order-independent. An undeclared parent, a
subset declared twice, a qualifier repeated among the subsets of one set, and an
identifier another type already has fail with source-located diagnostics.

Declaration and alias names are unique across the fence and share that namespace with
external parameters, concept-local types, and SSF primitives, and a subset's identifier
(its words joined, as `VerifiedUsers`) may not collide with them. Field names are unique
within their declaration, and enumeration values within their enumeration. Prefix a field with `unique` to require
distinct values among members of that declaration; a unique collection field compares the
whole collection. Require a _combination_ to be distinct with a `unique` line joining
field names with `and`, such as `unique item and voter`. The modifier is shorthand for a
line naming one field, so the line form is what a subset uses to constrain a field it
inherits rather than declares; a subset's constraints bind only its own members. A
field's lowercase name comes before its value unless the type names it, and `optional`
and `unique` sit between any article and that name in either order.

Invariant prose that SSF cannot express goes on a `Rule:` line, at the top level or
indented under a declaration. The parser retains the line and makes no claim about it,
while every other nonblank line must parse as a declaration, alias, or field. An
unrecognized field value is retained as unresolved in the IR and fails the check.
Operation signature types need not appear in State, but each must resolve against the
same declared, owned, local, or primitive universe; a subset identifier in a signature
fails with `SSF_SUBSET_SIGNATURE_TYPE`. Signature names first supply plural-join evidence; tooling
then validates them against the resolved inventory, so a singular spelling established
only by that join is accepted. The parser does not prove rules, type meaning, action
conditions or effects, query meaning, storage layout, State/storage agreement, or
implementation behavior.

Config-based checking accepts a qualified external-binding target that names an owned
declaration, an owned alias, or a joined subset identifier of the selected target instance's
definition. For example, a declared `Selected Humans` subset can be targeted as
`Directory.SelectedHumans`, or `Directory.SelectedHuman` when that singular spelling
resolves in SSF. Subsets of external types are also valid targets. A subset binding
records an authored membership requirement; it does not enforce implementation behavior
or membership at runtime. Action/query signature types still cannot name subsets.
Checked manifests persist the owned-name inventory in `ownedTypes`; validation rederives
that inventory and subset identifiers independently from State and operation signatures.
External parameters, primitives, unresolved names, and top-level sets of external types
cannot be binding targets. State changes continue to affect canonical design digests.

## `Actions`

`Actions` contains exactly one `actions` fence and declares at least one action.
Each action has this shape:

```text
actionName(input: Type, optional?: Type) : returns (result: Type)
  where condition prose
  then
    effect prose
    returns result
```

The exact requirements are:

- the signature has parenthesized named input fields;
- `: returns` is followed by parenthesized named result fields;
- one or more explicit `where`/`then` branches follow the signature;
- an unconditional branch uses `where true`;
- each `then` block ends with exactly one `returns ...` or
  `refuses CODE "Normative sentence."` line; and
- bare result types are rejected.

An empty successful result is written as `()` and terminates with plain
`returns`. For a nonempty result, every successful branch returns exactly the
signature's result names, irrespective of order.

A refusal code may occur only in the action that declares it. The sentence is
the normative caller-facing detail and supports JSON string escapes.
`registerConcept` requires the existing one-to-one mapping between refusal codes
and distinct `Error` classes and rejects extra mappings.

Conditions and effects are controlled prose. The parser checks branch and
terminal shape but does not prove their meaning or execute them.

## `Queries`

`Queries` contains exactly one `queries` fence. The fence may be empty. A query
has this signature:

```text
_query(input: Type) : one (field: Type)
_query(input: Type) : optional (field: Type)
_query(input: Type) : many (field: Type)
```

Input and result fields are parenthesized and named. Bare result types are
rejected. The optional indented body is arbitrary prose; no word such as
`answers` or `orders` is required by the parser. The broader authored-design guidance
is stricter: every query includes a body explaining its answer, unknown or empty case,
and deterministic ordering for `many`.

The cardinalities retain their runtime meaning:

| Choice     | Required evaluated result                     |
| ---------- | --------------------------------------------- |
| `one`      | Exactly one non-null, non-array object        |
| `optional` | An array containing zero or one object row    |
| `many`     | An array containing any number of object rows |

Reactions, views, and formers enforce this container/cardinality contract when
they evaluate a query. A query body remains a design statement rather than an
executable assertion.

## Names and type expressions

Action names begin with an ASCII letter. Query names begin with `_`. Field
names begin with an ASCII letter or `_`; subsequent characters may also be
digits. Names must be unique in their applicable scope.

Type expressions remain implementation-language-independent references. Every named
node, including a nested type argument or union member, must resolve to an owned,
external, concept-local, or primitive type. `null` and `undefined` introduce no names.
Resolved expressions do not establish runtime schemas or semantic equivalence with
TypeScript types. In particular, a concept identity commonly erases to `string` in an
implementation.

## Agreement with TypeScript

Config-based `sync-engine check` compares selected concept declarations with
resolved TypeScript source. It checks:

- action and query member names;
- input field names and optionality;
- action-result field names and optionality;
- query-row field names and optionality;
- registered refusal mappings; and
- query cardinality through the existing runtime read checks.

For optionality, `field?: T` and `field: T | undefined` are equivalent. Static
checking fails closed when it cannot resolve an input, action-result, or query-row
shape. It does not claim semantic type-name equivalence or State/storage
agreement.

Each successful action branch's terminal `returns` names are checked against the
declared result fields. Conditions, effects, query-body meaning, persistence,
transactions, and durability remain implementation and test responsibilities.

## Definition and instance identity

One registration can be installed under several application names:

```text
conceptSet({
  PostComments: commenting,
  AnswerComments: commenting,
})
```

`conceptSet` maps every selected application instance name to the registered
concept definition it realizes. Both entries above use the `Commenting`
definition. The configured application corpus must declare that exact static
selection:

```instances
instantiate Commenting as PostComments with
  User is Person
  Target is Posting.Post

instantiate Commenting as AnswerComments with
  User is Person
  Target is Answering.Answer
```

`instantiate Definition` means exactly `instantiate Definition as Definition`.
A definition does not require a same-name instance. Every config is checked
against the exact assembly it returns, and the core-owned `RequestBoundary` is
excluded from authored completeness. Generated design output records definition
and instance names separately.

If selected registrations use the same definition name, their canonical
specifications must be identical. Different implementation classes or floors
may implement that shared contract; incompatible specifications cannot claim
the same definition name. Authored instance declarations are a finite design
inventory, not runtime instance creation or storage allocation.

## Source provenance

`registerConcept` continues to receive imported Markdown text:

```text
import spec from "@design/concepts/Commenting.md" with { type: "text" };
registerConcept({ class: Commenting, spec });
```

Strict config-based checking traces the import that supplies `spec`, verifies
that its file contents match the registered text, and records the source path.
Dynamic or unresolvable specification construction fails the check. The
registration API does not accept a duplicate source URL. The source path and
filename have no effect on the contract; the authoring guide recommends a
consistent design-first layout without making it a checker requirement.

The stable IR format is `sync-engine.concept-specification`, version `1`.
Incompatible legacy beta specifications are not parsed or auto-detected. Stable
changes follow the [support policy](../../../SUPPORT.md#stable-compatibility).

## Author obligations

Write the concept contract before its implementation and run `sync-engine
check-design` over the draft. Keep the concept independent of application
composition, place every local invariant in its owning action and State description,
and test behavior and storage guarantees separately. Then register the imported text,
select the registration in a `conceptSet`, and run `sync-engine check` against the
application's generated config.

See [Application authoring](../guide/authoring.md) for the complete workflow and
[Command-line reference](cli.md#sync-engine-check) for command behavior.
