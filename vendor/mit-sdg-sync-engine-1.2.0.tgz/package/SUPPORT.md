# Support policy

## Public surface

The core package supports these six subpaths:

- `@mit-sdg/sync-engine/language`
- `@mit-sdg/sync-engine/assembly`
- `@mit-sdg/sync-engine/boundary`
- `@mit-sdg/sync-engine/client`
- `@mit-sdg/sync-engine/tooling`
- `@mit-sdg/sync-engine/advanced`

The package root and deep imports are unsupported. The [core Public
API](docs/user/reference/public-api.md) is the exact export register.

Each independently published package defines its own exports, compatibility,
runtime requirements, and support boundaries in its package README.

## Stable compatibility

Stable 1.x versions have the form `1.MINOR.PATCH`, across every supported public
subpath, including `/advanced`. Patch releases contain backward-compatible fixes.
Minor releases may add functionality and may also change public APIs, behavior,
or accepted specification syntax incompatibly. The [changelog](CHANGELOG.md)
records compatibility and migration effects for every release. Pin an exact
version for reproducible coursework and review the changelog before upgrading.
An option marked experimental may change or be removed in any minor release;
the changelog lists the change. `concurrentReads` is experimental.

Published versions, tags, and tarballs are immutable. A correction receives a
new version; maintainers do not replace an existing release.

Only the newest stable 1.x release receives fixes. Earlier stable releases must
upgrade; fixes are not backported to older release lines. Alpha and beta releases
are unsupported.

The current `RetentionPolicy` surface contains only `"keepAll"` and
`{ window: number }`. The earlier prerelease `"evictConsumed"` policy and manual
pruning interfaces are unsupported.

## Generated contracts

Generated Markdown and TypeScript wire files record the core generator and each
projector version that produced them. Regenerate and review generated files
after changing a package version, then typecheck their consumers.

`sync-engine.application-manifest` version 1 is the versioned core format. This
schema reset records the registered authored-design contract, including concept
external types, full State text, exact structural, safely evidenced, and explicit-alias definition-owned type
inventories, complete authored instance declarations and external bindings, declaration coverage,
and computation signatures. It also contains executable application
and wire facts, implementation provenance, validators, and diagnostics. It does
not contain functions, constructor arguments, resources, object identity,
occurrences, timestamps, or other runtime state.

Earlier application-manifest shapes are rejected rather than upgraded and must
be regenerated. The stable version-1 schema is no longer reset in place. An
incompatible structural or semantic change requires a new integer format version
and new public type names; removal or incompatible replacement of a supported
public contract also requires a new package major version. A package release does not change the format version when the
existing structure and meaning remain compatible. The artifact planner accepts
1.x core generator identities and projector provenance with a nonblank package name and valid SemVer version,
including prereleases.

## Runtime and toolchain

The supported core runtime and toolchain ranges are:

| Surface                                | Supported range     |
| -------------------------------------- | ------------------- |
| Built ESM library                      | Node.js `>=24 <25`  |
| Core CLI, setup, scripts, and examples | Bun `>=1.3.4 <2`    |
| Type checking and generated TypeScript | TypeScript `>=6 <7` |

CI runs on current GitHub-hosted Linux, macOS, and Windows images. Filesystems,
databases, proxies, TLS, process management, and browser behavior remain host or
application responsibilities. Review the [operational
limits](docs/user/reference/operations.md) before deployment.

## Getting help

Search or open a [GitHub issue](https://github.com/mit-sdg/sync-engine/issues)
for reproducible support requests. Include exact package, runtime, and
TypeScript versions, the public subpath in use, a minimal reproduction, and
relevant generated-file diffs. Report suspected vulnerabilities only through
the private process in the [security policy](SECURITY.md).
