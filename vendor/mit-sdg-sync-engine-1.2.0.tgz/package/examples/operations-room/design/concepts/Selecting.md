# Selecting

## Purpose

Keep one current item for a shared scope, so everyone working in that scope can
begin from the same choice.

## Principle

A workshop chooses Essay A and it becomes the workshop's current selection.
Later it chooses Essay B; the new selection replaces Essay A as current without
changing another workshop's selection. Clearing the workshop removes its
current selection. A second clear is refused because there is nothing left to
clear.

## Types

```types
external Scope
  The context in which one item is current.
external Item
  The object selected within a scope.
```

## State

```state
a set of Selections with
  a unique scope Scope
  an item Item

a set of Current Selections
```

## Actions

```actions
choose (scope: Scope, item: Item) : returns (selection: Selection)
  where true
  then
    delete any Selection with scope
    add a new selection with scope and item
    add selection to Current Selections
    returns selection

clear (scope: Scope) : returns (selection: Selection)
  where some current selection has scope
  then
    delete that Selection
    returns selection
  where no current selection has scope
  then
    refuses NO_CURRENT_SELECTION "This scope has no current selection."
```

## Queries

```queries
_current (scope: Scope) : optional (selection: Selection, scope: Scope, item: Item)
  answers the Scope's current Selection and its Item
  answers no row for a Scope with no current Selection
_get (selection: Selection) : optional (selection: Selection, scope: Scope, item: Item)
  answers the Selection's identity, Scope, and Item
  answers no row for an unknown Selection
```
