# Changelog

This project follows semantic versioning. During beta, public subpaths,
behavior, and generated formats may change incompatibly between releases. Pin
an exact version, follow the [support policy](SUPPORT.md), and review the
[operational limits](docs/user/reference/operations.md) before deployment.

## [1.0.0-beta.18] - 2026-10-11

This beta adds a query cache mode that keeps a running invocation's answers when
another invocation arrives, so concurrent invocations stop re-reading what they
had read. Nothing changes unless an assembly asks for it.

### Compatibility

- New `queryCache` mode `"since-dispatch"`. Until an outside invocation settles,
  reads done for its flow reuse only memoized answers whose query began at or
  after it was dispatched, the freshness the default mode gives by clearing
  every cache at dispatch, while invocations already running keep the answers
  they read. A direct `form` and a direct query root read the same way from
  their own start; any other read reuses only answers begun since the latest of
  those starts. Action invalidation is unchanged.
- `createInvoker`'s `refresh` receives the flow the ask's request runs in once
  admitted, and a function it returns is called once the ask has settled,
  admitted or not. It runs where it always has, before input validation, and a
  `refresh` taking no argument still works.
- A direct query root under `"since-dispatch"` no longer clears that query's
  answers for running invocations.

### Migration

None. To keep answers across invocations, pass `queryCache: "since-dispatch"`
to `assemble`.

### Generated formats

None.

### Runtime and security support

None.

[Release][1.0.0-beta.18] | [Changes since 1.0.0-beta.17][1.0.0-beta.18-compare]

## [1.0.0-beta.17] - 2026-10-10

This beta lets an assembly read the rows of a line or selection together, so
independent reads overlap instead of waiting on one another. Nothing changes
unless an assembly asks for it.

### Compatibility

- New assembly option `concurrentReads: { rowsAtOnce, maxRowsAhead? }`. With
  it, a line applied to many frames and a selection forming many rows evaluate
  up to `rowsAtOnce` rows at once, the consumed row included, and consume them
  in row order. At most `maxRowsAhead` rows (64 when unset) are started ahead at
  once across the assembly, and an evaluation that finds that count spent reads
  its next row when it reaches it. Answers, their order, the reported fault,
  and recorded row-limit breaches are those of reading one after another, given
  side-effect-free reads and no action changing the state being read meanwhile.
  A fault is reported as soon as its row is consumed; rows started ahead then
  stop at their next row check. Without the option, rows are read one after
  another as before.
- `@mit-sdg/sync-engine/assembly` exports the `ConcurrentReads` type.
- The reference now states that computations, conditions, and custom ops used
  by reads must be free of side effects, as queries already had to be.

### Migration

None. To read rows together, pass `concurrentReads: { rowsAtOnce: 16 }` to
`assemble`, and size the database client's connection pool above
`maxRowsAhead` plus the evaluations expected at once.

### Generated formats

None.

### Runtime and security support

None.

[Release][1.0.0-beta.17] | [Changes since 1.0.0-beta.16][1.0.0-beta.17-compare]

## [1.0.0-beta.16] - 2026-08-22

This beta makes endpoint paths part of the checked authored design, fixes analysis
of Bun application projects, and replaces the skill coordinator with resumable,
capability-recorded work units across six supported harnesses.

### Compatibility

- Application design documents use `endpoints` fences containing
  `Declaration.Identity at /path`. Every selected endpoint must have exactly one
  authored declaration whose identity and portable absolute path match the
  executable endpoint. Endpoint declarations supplement rather than replace the
  endpoint tree's `reaction:` link coverage.
- `check-design` validates endpoint declaration syntax and duplicates without an
  assembly. Config-based `sync-engine check` additionally rejects unresolved
  endpoint identities, path mismatches, and missing endpoint declarations.
- Analysis launches a packaged core `sync-engine` command with Bun rather than
  the analysis CLI's Node executable, raises the default `maxAstCandidates` from
  100,000 to 1,000,000, and compares manifest diagnostics without depending on
  producer order.
- Successful human-readable `sync-engine check` and `verify` output summarizes
  application advisories instead of listing each one. `--show-advisories` lists
  them; `--fail-on-warnings` still lists diagnostics that cause failure, and
  JSON output retains the complete diagnostic array.
- The skill coordinator now keeps each bounded change under
  `.sync-engine/work/<slug>/`, with typed role phases, explicit capability
  grants, prepared and finalized launch records, captured responses, and
  same-identity continuation. Its previous brief, assignment, launch, follow-up,
  and handback command workflow is replaced.
- Skill harness adapters support Paseo, Pi, Codex, Claude Code, Antigravity, and
  Cursor. Capability grants are recorded and checked against role maxima, but
  remain prompt-guided unless the selected harness reports enforcement.
- Design work is split into decomposition and contract authoring with separate
  criticism phases. Verification, concept, application, optional frontend, and
  evidence roles receive phase-specific guidance and retained inputs.

### Migration

- Install core, HTTP, analysis, catalog, and skill at `1.0.0-beta.16` when they
  are used together.
- Add an `endpoints` fence to the authored application design for every selected
  endpoint, using its exact declaration identity and route path. Keep the
  existing `reaction:` link that covers the endpoint's reaction tree.
- Start new skill work with `sync-engine-skill work start <slug>` and follow the
  new prompt, launch, completion, and continuation flow. Previous top-level
  `.sync-engine/` launch records do not satisfy the new work-unit workflow.
- Ensure Bun is available when the Node-based analysis CLI resolves and invokes
  a packaged core command from a Bun application project.
- Add `--show-advisories` to existing human-readable check invocations that
  depend on individual warning and informational lines.

### Generated formats

- Core application manifests remain at version 1. A checked endpoint
  declaration now contributes its source location to the endpoint declaration's
  existing `coverage` array, alongside reaction-link provenance when present.
- Analysis application indexes, impact traces, source indexes, and project
  snapshots remain at version 3, unchanged in shape.
- The skill replaces `sync-engine.skill.launch-record` files at the top of
  `.sync-engine/` with per-work-unit task, capability, prompt, response, and
  prepared/finalized record files. The previous records are not consumed by the
  new coordinator.
- Regenerated declarations and example application artifacts update package and
  projector provenance to `1.0.0-beta.16`.

### Runtime and security support

- Supported Node, Bun, TypeScript, and security windows are unchanged.
- Analysis remains a Node executable, but invokes the packaged core command with
  Bun so Bun configuration can load correctly. The higher AST candidate default
  increases bounded discovery work without changing the one-million retained-node
  limit.
- Skill capability grants are auditable coordination evidence, not a sandbox;
  the underlying harness determines technical access and enforcement.

[Release][1.0.0-beta.16] | [Changes since 1.0.0-beta.15][1.0.0-beta.16-compare]

## [1.0.0-beta.15] - 2026-08-20

This beta gives the design skill a separate decomposition review before concept
contracts are written, adds a framework-owned instant shared across each causal
flow, and narrows the catalog to reusable single-mechanism entries.

### Compatibility

- `now(variable)` is exported from `@mit-sdg/sync-engine/language`. It is valid
  only in a reaction or endpoint `where` stage and binds the instant stamped on
  the causal flow's outermost occurrence. Every reaction in one flow observes
  the same `Date`; the flow and its outermost log occurrence use one clock read.
  Registration rejects `now` in views and formers and rejects a variable already
  authored by an action trigger or `receive(...)`.
- `assemble` accepts an optional `clock: () => Date`. The default is the system
  clock. The clock is called once when each causal flow opens, and a return value
  that is not a valid finite `Date` fails that flow.
- The skill writes and reviews `design/decomposition.md` before concept files.
  Each concept row identifies the needs served, catalog match, opaque subject,
  and a second unrelated application; each cross-concept obligation identifies
  its permitted false interval and recovery. The decomposition critic returns an
  `accept`, `split`, or `merge` ruling for every row. Later contract review checks
  the settled obligations without reopening boundaries.
- The complete generated catalog listing is included in every designer prompt
  and checked for staleness. Added the `Expiring`, `Registering`, and `Tallying`
  concepts. Removed `Discussing`, `Gathering`, and `Timing`, and removed the
  `incident-room`, `invite-only-workshop`, `member-reservations`,
  `ranked-discussion`, and `workshop-selection` recipes that depended on the
  bundled concepts. `now` replaces `Timing` as the source of a flow instant.
- `Sessioning.start` now requires `lifetime` in milliseconds and `now`, and
  refuses a lifetime that is not positive and finite with
  `INVALID_SESSION_LIFETIME`. `Sessioning.current`, `Sessioning.end`, and
  `Sessioning._active` now require `now`; expiration is explicit and no longer
  depends on a clock hidden in the implementation.
- `Selecting.choose` and `Selecting.clear` delete the superseded selection
  instead of leaving a non-current record addressable through `_get`.
- Catalog concept queries now state their successful rows as well as their empty
  case, and `many` queries state a stable ordering.
- The application-worker prompt includes concrete accepted reaction triggers,
  response and refusal forms, and the required exported `composition` record.
  Example selection now checks that the chosen examples demonstrate every
  mechanism used by the design.

### Migration

- Install core, HTTP, analysis, catalog, and skill at `1.0.0-beta.15` when they
  are used together.
- Replace a `Timing` instance and its `_now` read with
  `.where(now(instant))`, then pass `instant` to each concept action that
  declares it. Inject `clock` through `assemble` when tests need a fixed time.
- Update `Sessioning` calls to pass an explicit positive finite `lifetime` to
  `start` and a `now` value to `start`, `current`, `end`, and `_active`.
- Stop importing the removed catalog concepts and recipes. Replace their bundled
  behavior with independently selected mechanisms; use `Registering` for
  deduplicated occurrences, `Tallying` for totals, and `Expiring` for deadlines
  where those contracts fit.
- Regenerate a skill-authored design from the decomposition stage. Existing
  designs without `design/decomposition.md` do not satisfy the new staged
  designer and critic workflow.

### Generated formats

- Version-1 application manifests gain the `{"op":"now","out":"..."}`
  reaction where-operation variant. The manifest version remains 1; `now` is
  rejected in view and former operations.
- Analysis application indexes, impact traces, source indexes, and project
  snapshots remain at version 3, unchanged in shape.
- Regenerated declarations and example application artifacts update package and
  projector provenance to `1.0.0-beta.15`.

### Runtime and security support

- Supported Node, Bun, TypeScript, and security windows are unchanged.
- The flow instant is framework-owned: request input and action-trigger values
  cannot forge a `now` binding. An injected `clock` is privileged assembly code
  and determines both the outermost occurrence stamp and every `now` binding in
  that flow.

[Release][1.0.0-beta.15] | [Changes since 1.0.0-beta.14][1.0.0-beta.15-compare]

## [1.0.0-beta.14] - 2026-08-19

This beta makes the skill's role launches verify themselves against the harness
rather than against the coordinator's account, binds every delivery to the design
digest it was built for, and lets an HTTP policy declare direct `GET` routes for
clients that cannot post.

### Compatibility

- `httpPolicy` accepts `direct`, the routes an application serves outside
  POST/JSON for a client that cannot post. A route names a `GET` path whose
  `{name}` segments fill the endpoint inputs of those names, percent-decoded; an
  empty segment does not match. `redirect` names a response field holding an
  absolute URL and answers `302`; `status` alone answers that status with the
  JSON body; a route must state one of them. Parameter names may not repeat, two
  routes may not share a method and shape, and the endpoint keeps its `POST`
  path. `HttpDirectRoute` is exported from `@mit-sdg/sync-engine-http`.
- A direct route carries no cookies and skips the request-origin check, so
  `httpPolicy` refuses one that serves an endpoint issuing or clearing a cookie.
- `sync-engine setup` writes a `tsconfig.json` that maps `@design/*` to
  `./design/*`, which the shipped examples already use.
- The skill's `launch` reads the role's last message and the paths it opened from
  the harness, so a role cannot be recorded as doing work it did not do. The
  reply is written to `<stamp>-<role>.response.md` under `.sync-engine/` and
  summarized in the launch record. A reply that breaks its role's contract fails
  the launch and does not count the role as run; a critic must return
  `No material findings.` or begin with its findings, with no preamble.
- A role that ends in error is inspected again after a pause and then asked to
  continue, up to twice, before its launch fails.
- A read outside a role's boundary is recorded in the launch record and reported
  by `handback check` rather than failing the launch. No role may read the
  skill's own sources except `SKILL.md`, a designer or critic may read no
  installed package, and an implementation role may read only a `@mit-sdg`
  package's `examples/` and `docs/user/`. A harness that names its tools without
  their arguments records `readAudit: "unavailable"` rather than attesting to a
  boundary it never saw.
- `prompt build` counts a predecessor launch only when that launch ran against
  the same `--design-digest`, and it names the stale digest when design was
  reopened after the earlier role ran.
- Added `follow-up new --role <role>`, which names the follow-up file.
  `follow-up check` now requires a compiler-named file that states its role.
- `design digest` requires each concept document to be `concepts/<Concept>.md`,
  matching the name in its heading.
- `assignment check` reads owned paths from the `Allowed write paths` section
  alone, so bulleted read paths elsewhere in an assignment no longer claim
  ownership.
- Added the packaged `prompts/inputs/composition.md` reference for the `language`
  and `boundary` declaration API: reactions, views, formers, computations, and
  endpoints. Every application worker receives it as a `reference` input, and an
  HTTP product adds `prompts/inputs/http.md`.
- An application worker treats `MISSING_COVERAGE`, `UNRESOLVED_LINK`,
  `UNDECLARED_SELECTED_INSTANCE`, and `UNREGISTERED_COMPUTATION` as design
  defects to block on rather than defects to repair.
- Unknown roles and unknown input slots report the accepted values.

### Migration

- Replace hand-written listeners and route matching for browser-reachable `GET`
  paths with policy `direct` routes. The endpoint itself does not change.
- Install core, HTTP, analysis, catalog, and skill at `1.0.0-beta.14` when they
  are used together.
- Rename each concept document to match its heading before taking a design
  digest, and move every owned path in a temporary assignment under
  `## Allowed write paths`.
- Start diagnostic follow-ups with `follow-up new --role <role>` instead of
  naming the file yourself.
- Rebuild prompts and relaunch roles after reopening design. A delivery recorded
  against another digest no longer satisfies the role that follows it.
- Pass `<skill-root>/prompts/inputs/composition.md` to every application worker.

### Generated formats

- The version-1 `sync-engine.skill.launch-record` gains the optional `response`,
  `readViolations`, `readAudit`, and `resumes` members. Records written by
  1.0.0-beta.13 remain readable; a role relaunched under this release records its
  reply. `.sync-engine/` gains the `<stamp>-<role>.response.md` file kind.
- Core application manifests remain at version 1 and analysis application
  indexes, impact traces, source indexes, and project snapshots remain at
  version 3, unchanged in shape.
- Regenerated declarations and example application artifacts update package and
  projector provenance to `1.0.0-beta.14`.

### Runtime and security support

- Supported Node, Bun, TypeScript, and security windows are unchanged.
- A direct route answers before the request-origin check and emits no cookie or
  CORS headers. Its endpoint still owns authorization, and its redirect target
  comes from that endpoint's own response value, so an endpoint reachable by a
  direct route must treat its path segments as untrusted input.
- The read audit is evidence, not a sandbox. It reports what the harness observed
  after the role ran, it does not confine a role, and an audit the harness cannot
  supply is recorded as unavailable rather than as clean.

[Release][1.0.0-beta.14] | [Changes since 1.0.0-beta.13][1.0.0-beta.14-compare]

## [1.0.0-beta.13] - 2026-08-19

This beta makes application designs declare their concept instances explicitly,
parses Simple State Form instead of carrying it as opaque text, reports coded
diagnostics with machine-readable output, and adds one gate command and a
manifest differ.

### Compatibility

- Application design now declares an explicit static instance inventory.
  `instances` fences hold `instantiate Definition [as Instance] [with ...]`
  declarations, `bindings` fences hold detached `Instance.External is Target`
  declarations, and `types` fences hold only `concrete Name` declarations with
  prose. One definition may have several differently named instances. Each
  instance places its bindings inline or detached, never both. The core-owned
  `RequestBoundary` stays outside the authored inventory.
- Concept-set keys and the `assemble` `instances` option name application
  instances rather than concept definitions. Within one assembly, two names
  cannot use the same raw implementation object, and each `implementations(...)`
  call constructs one object per selected key.
- Simple State Form is parsed. The bounded parser recognizes set, sequence,
  element, subset, alias, and field declarations with their multiplicities,
  articles, identifiers, subset graph, and name uniqueness, and it resolves
  qualified external-binding targets against the names a concept owns. Two
  authored spellings of one owned type join when they form an unambiguous
  singular and plural pair, including irregular pairs; `alias Alias for Target`
  states a synonym directly. An ambiguous pair reports advice without failing
  the check. External type names take the uppercase type-name form and may not
  reuse an SSF primitive.
- Invariant prose belongs on a `Rule:` line inside the `state` fence. Every
  other nonblank line must parse. Prose after the fence, and unparseable lines
  that earlier passed as opaque text, are now reported.
- `parseConceptSpecification` returns `ConceptSpecParseResult` with accumulated
  coded diagnostics and source locations instead of throwing at the first fault;
  the throwing entry point is gone. `ConceptSpecDiagnostic`,
  `ConceptSpecDiagnosticCode`, and `ConceptSpecParseResult` are exported from
  `@mit-sdg/sync-engine/tooling`. `check-design` reports every fault in every
  supplied file rather than stopping at the first.
- Added `sync-engine verify [--config path] [--fail-on-warnings]`. It runs the
  configured design, application, and artifact checks, adds no checks of its
  own, and runs each step independently so one failure cannot hide another.
- Added `sync-engine artifacts diff <old-manifest>`, which reports what changed
  against a saved manifest, splits the changes into breaking and non-breaking,
  exits non-zero on a breaking change, and refuses a manifest it cannot decode.
- Added `--format json` to `check`, `check-design`, `artifacts check`, and
  `verify`. In JSON mode a command writes exactly one document to stdout,
  suppresses its human-readable text, and still exits 1 on failure.
- `sync-engine setup` writes a `.gitignore` when the application has none and
  leaves an existing one untouched.
- The skill launches every role through its own compiler rather than the harness
  CLI. `launch` drives Paseo today, reusing the coordinator's provider, model,
  and reasoning setting, and writes a launch record under `.sync-engine/`.
  Building a role's prompt requires a settled record for the role before it, and
  handback requires one for every required role. Independence and placement
  rules for role-written code are now mechanical, and
  `references/harnesses/contract.md` states what another harness must supply.
- Fixed a manifest defect the differ exposed: an endpoint declaring no input
  options was omitted from the copied input contracts, so the application
  produced a manifest its own validator rejected.

### Migration

- Rewrite each application `types` document. Move every concept instance into an
  `instances` fence and every external binding into that instance's `with` block
  or a `bindings` fence. Keep `types` fences to `concrete Name` declarations.
  Update concept-set keys and any `instances` argument to name application
  instances.
- Move invariant prose from below the `state` fence onto `Rule:` lines inside
  it, and repair State lines that earlier survived as opaque text. Run
  `sync-engine check-design <paths...>` to enumerate the remaining faults.
- Update `parseConceptSpecification` callers to read the returned result and
  decide for themselves whether to abort; it no longer throws.
- Regenerate artifacts with `sync-engine artifacts pin`. Manifests saved by an
  earlier beta are rejected rather than upconverted; keep a regenerated manifest
  as the baseline for `artifacts diff`.
- Install core, HTTP, analysis, catalog, and skill at `1.0.0-beta.13` when they
  are used together. Existing skill users should regenerate prompts through the
  packaged compiler and launch roles with `launch`, since later stages require
  launch records.

### Generated formats

- Core application manifests remain at version 1, but the schema is replaced in
  place: manifests written by earlier betas are rejected without upconversion.
  Generated Markdown replaces its selected-instances-and-bindings section with
  an `Instances` section that names each instance, its definition, and its
  bindings.
- Added the version-1 `sync-engine.diagnostic-report` document for
  `check-design`, `check`, and `artifacts check`, and the version-1
  `sync-engine.verification-report` document for `verify`. Unavailable facts are
  omitted rather than encoded as `null` or synthetic coordinates.
- Analysis application indexes, impact traces, source indexes, and project
  snapshots remain at version 3.
- Regenerated declarations and example application artifacts update package and
  projector provenance to `1.0.0-beta.13`.

### Runtime and security support

- Supported Node, Bun, TypeScript, and security windows are unchanged.
- State parsing, JSON diagnostics, `verify`, and manifest diffing are static
  tooling. They do not add runtime schema validation, authorization,
  persistence, transactions, or frontend trust guarantees; endpoint policies and
  operational controls remain application responsibilities.
- Separate implementation objects are not proof of separate durable state. A
  persistent floor factory should use its instance-name argument to select an
  explicit repository, collection, schema, or namespace when isolation is
  required.

[Release][1.0.0-beta.13] | [Changes since 1.0.0-beta.12][1.0.0-beta.13-compare]

## [1.0.0-beta.12] - 2026-08-16

This beta adds a deterministic, self-contained Agent Skill prompt workflow and
an assembly-independent design form check, and gives frontend implementation an
explicit endpoint-only role.

### Compatibility

- Added `sync-engine check-design <paths...>` for an explicit mixed corpus of
  concept, composition, and application-types Markdown. It applies the strict
  concept parser, application-design form checks, and limited repair-oriented
  Simple State Form checks without loading configuration, assembly, TypeScript,
  or Git state.
- Removed the narrower `sync-engine check-concepts` command. `check-design`
  checks concept documents and also accepts application-design documents.
- Renamed the catalog executable from `catalog` to `sync-engine-catalog`; the old
  executable name is no longer installed.
- The skill now includes deterministic product-brief, release-set, design-digest,
  follow-up, and prompt-compilation commands. Its embedded TypeScript sources
  bootstrap without installing application dependencies, while the npm package
  also exposes the `sync-engine-skill` convenience executable.
- Added a bounded frontend worker for briefs that request a browser, command-line,
  or other shell. The worker consumes generated endpoint wire contracts and may
  not import concepts, composition, assembly, or storage.

### Migration

- Replace `sync-engine check-concepts <paths...>` with
  `sync-engine check-design <paths...>`. Treat its Simple State Form checks as
  repair guidance only; config-based `sync-engine check` remains responsible for
  selected-assembly links, coverage, source agreement, and TypeScript shapes.
- Replace invocations of the removed `catalog` executable with
  `sync-engine-catalog`.
- Install core, HTTP, analysis, catalog, and skill at `1.0.0-beta.12` when they
  are used together. Existing skill users should regenerate prompts through the
  packaged compiler rather than carrying earlier role-reference text forward.

### Generated formats

- Core application manifests remain at version 1. Analysis application indexes,
  impact traces, source indexes, and project snapshots remain at version 3.
- Regenerated declarations and example application artifacts update package and
  projector provenance to `1.0.0-beta.12`; no persisted-format version changes.

### Runtime and security support

- Supported Node, Bun, TypeScript, and security windows are unchanged.
- Design form checking and skill prompt compilation are static tooling. They do
  not add runtime schema validation, authorization, persistence, transactions,
  or frontend trust guarantees; endpoint policies and operational controls
  remain application responsibilities.

[Release][1.0.0-beta.12] | [Changes since 1.0.0-beta.11][1.0.0-beta.12-compare]

## [1.0.0-beta.11] - 2026-08-15

This beta adds a design-first Agent Skill and read-only analysis command, makes
application setup complete a compatible Bun package, tightens draft concept
syntax, and narrows catalog examples to the memory implementation.

### Compatibility

- Added `@mit-sdg/sync-engine-skill` with a compact native-agent workflow for a
  Markdown product brief, independent design and bounded criticism, separated concept
  and application implementation, objective evidence, and stop-after-success
  validation. Its skill directory embeds the TypeScript brief validator and deterministic
  file-based prompt compiler so a new application can bootstrap before installing
  dependencies. A release manifest pins the matching core, analysis, and catalog
  packages, with no public JavaScript API or workflow database.
- Renamed the catalog executable from ambiguous `catalog` to
  `sync-engine-catalog`. The old executable name is no longer installed.
- `@mit-sdg/sync-engine-analysis` now installs the read-only
  `sync-engine-analysis` command. It obtains the configured V1 manifest through
  core and provides bounded `summary`, `search`, `describe`, `sources`, `impact`,
  and `diagnostics` projections without writing application files.
- `sync-engine setup` now adds the canonical Bun `packageManager` when absent,
  completes missing managed package fields, installs dependencies when it
  changes the manifest, and then creates missing concept-free templates.
  Compatible existing dependency declarations and all existing scripts are
  preserved; conflicting or incompatible declarations fail before the manifest
  is written.
- Added `sync-engine check-concepts <paths...>` for syntax-only validation of
  explicit draft concept files without loading application configuration or
  TypeScript. The version-1 parser now rejects subsection headings, fenced
  blocks in Purpose or Principle, and application-design links or computations
  fences anywhere in a concept specification.
- Catalog concept entries no longer ship MongoDB implementations or their
  selectors. All 16 entries retain the memory implementation, and the catalog
  remains a read-only source browser rather than a persistence library.

### Migration

- Before rerunning `sync-engine setup`, review any partially authored package
  manifest. Setup can now add the canonical Bun `packageManager`, exact core,
  TypeScript, and `@types/node` dependencies, add absent standard scripts, write
  `package.json`, and run `bun install`; it still never overwrites an existing
  script or application file.
- Remove subsection headings and fenced blocks from concept Purpose and
  Principle sections, and move application links and computation declarations
  into registered application-design documents. Use `check-concepts` while the
  design is still a draft, then use config-based `check` after registration.
- Catalog users that copied a MongoDB example must retain and maintain that
  application-owned source or provide their own persistent implementation. New
  catalog selection should use the remaining `memory/...` selectors and adapt
  storage deliberately.
- Install core, HTTP, analysis, catalog, and skill at `1.0.0-beta.11` when they
  are used together. The skill requires a harness with native isolated
  subagents; it pauses rather than simulating an independent review when those
  capabilities are unavailable.

### Generated formats

- Core application manifests remain at version 1. Analysis application indexes,
  impact traces, source indexes, and project snapshots remain at version 3.
- Regenerated declarations and example application artifacts update package and
  projector provenance to `1.0.0-beta.11`; no persisted-format version changes.

### Runtime and security support

- Supported Node, Bun, TypeScript, and security windows are unchanged. The new
  skill is orchestration documentation, and the analysis command is read-only
  static evidence rather than runtime proof.
- Catalog removal of MongoDB examples does not add a persistence guarantee to
  memory implementations. Applications remain responsible for durable storage,
  transactions, deployment controls, and recovery where required.

[Release][1.0.0-beta.11] | [Changes since 1.0.0-beta.10][1.0.0-beta.11-compare]

## [1.0.0-beta.10] - 2026-08-15

This beta replaces the preliminary authored-design workflow with one strict,
versioned application-design contract and makes registered concept sets the
ordinary application assembly abstraction.

### Compatibility

- Concept specifications now use the strict version-1 Purpose, Principle,
  external Types, raw State, structured Actions, and Queries grammar. Static
  checking compares registered TypeScript shapes and source provenance with
  that contract; unsupported or unresolved source shapes fail closed.
- Every generated config must register `design: { version: 1, documents }`.
  Ordinary registered Markdown may contain globally combined `types` and
  `computations` fences plus exact `reaction:`, `view:`, `former:`, and
  `computation:` links. There is no special application, vocabulary, types, or
  computations filename.
- `conceptSet(...)` now returns the complete ordinary assembly value. Pass it as
  `assemble({ conceptSet, composition })`; `.concepts` contains typed authoring
  references and `.implementations(...)` constructs implementation maps. The
  nested `.vocabulary` projection is removed.
- The conventional concept-set module is `src/concepts.ts`, exporting
  `applicationConceptSet`. Setup, source discovery, generated wire anchors,
  examples, and packaging fixtures use that convention.
- Direct `vocabulary(...)` declarations moved from `/language` to `/advanced`.
  Their option type moved from `/assembly` and is now
  `VocabularyAssemblyOptions` under `/advanced`.
- `sync-engine check` now requires a generated config. The removed
  `--vocabulary-module`, no-config compatibility mode, `design.vocabulary`, and
  generated-config `vocabulary` fields fail with migration guidance.

### Migration

1. Rewrite each concept specification into the strict six-section version-1
   grammar and register its imported Markdown with `registerConcept`.
2. Rename the conventional executable module to `src/concepts.ts`, export the
   result of `conceptSet(...)` as `applicationConceptSet`, and pass that whole
   object to `assemble` as `conceptSet`.
3. Move application type declarations and bindings into `types` fences in any
   registered `design.documents` file. Rename a dedicated
   `design/vocabulary.md` to `design/types.md` only when that topic-based split
   remains useful.
4. Add exact typed links for every selected authored reaction or endpoint tree,
   named view, and named former, and declare every executable computation once.
5. Replace `--vocabulary-module` and no-config checks with config-based commands,
   then regenerate manifests, read-back, wire contracts, and analysis artifacts.
6. Import direct low-level `vocabulary` declarations and
   `VocabularyAssemblyOptions` from `/advanced`; ordinary applications should
   migrate to `conceptSet`.

There is no legacy parser, compatibility flag, automatic format detection, or
old-manifest decoder. Rollback requires restoring the prior authored files,
config, package version, and generated artifacts together.

### Generated formats

- The canonical application manifest resets from version 5 to version 1 with no
  compatibility decoder. It carries strict concept specifications, normalized
  application types, exact declaration coverage, computation signatures, and
  design-source provenance.
- Analysis application indexes, impact traces, source indexes, and project
  snapshots advance from version 2 to version 3. Version-2 artifacts are
  rejected rather than upgraded.
- Regenerated read-back labels application type bindings as **Application
  types**. Generated wire imports anchor to
  `src/concepts.ts#applicationConceptSet`.

### Runtime and security support

- Supported runtimes, toolchains, and security windows are unchanged. Runtime
  assembly does not load application design Markdown; the complete authored
  contract is required by config-based checking and artifact commands.
- The release adds no transactions, rollback, replay, distributed
  serialization, accepted-work cancellation, runtime schema validation, or
  exactly-once execution. Existing operational limits remain in force.

[Release][1.0.0-beta.10] | [Changes since 1.0.0-beta.9][1.0.0-beta.10-compare]

## [1.0.0-beta.9] - 2026-08-13

This beta makes the curated catalog read-only, discovers checked concepts from
actual registrations, and establishes a conventional application-owned design
layout separate from executable source and generated evidence.

### Compatibility

- The application convention now keeps concept specifications under
  `design/concepts/`, lean composition explanations under
  `design/compositions/`, and an optional `design/vocabulary.md`. Executable
  declarations live under `src/concepts/`, `src/compositions/`, and
  `src/vocabulary.ts`; focused tests live under matching `tests/` directories.
  These paths are conventions rather than registration or runtime semantics.
- `sync-engine setup` now creates `src/vocabulary.ts` and no placeholder design
  or composition file. Its generated descriptor names that vocabulary module.
- `sync-engine check` discovers the selected runtime registrations instead of
  scanning Markdown roots. With `--config`, the assembled application's
  application-owned concepts are authoritative. Without a config,
  `--vocabulary-module` selects a module whose `vocabulary` export retains the
  registrations. The no-option compatibility default remains
  `src/concept-set.ts`; unregistered Markdown is ignored.
- Removed the `--concepts` check option. Source analysis now locates only the
  class declarations needed for TypeScript-erased input names and follows
  supported direct or imported registrations and registration-map spreads.
  Inherited method declarations are checked when runtime registration selected
  them; unsupported or unresolved source shapes fail rather than being omitted.
- `@mit-sdg/sync-engine-catalog` is now a read-only packaged-asset browser.
  Removed `catalog add`, floor selection, dependency planning, generated wiring,
  project inspection, installation transactions, and `catalog.lock` ownership.
  Added `catalog source <entry> <selector> [--raw]`; `catalog show` now prints
  the entry design and accepted selectors and also supports `--raw`.
- The catalog no longer has a core peer or a `semver` runtime dependency. Recipe
  requirements are display relationships only, and implementation names only
  label source selectors; neither triggers resolution or installation.

### Migration

Existing applications do not have to move files solely to keep registration or
runtime behavior. To adopt the layout, move authored Markdown under `design/`,
map `@design/*` to that directory, collect registrations in
`src/vocabulary.ts`, and keep executable composition groups and focused tests in
the matching `src/compositions/` and `tests/` directories. Configure
`generated.config.ts` with `vocabulary.module` when the module is not the legacy
`src/concept-set.ts` default.

Replace `sync-engine check --concepts ...` with `--config <path>` for
assembly-driven discovery or `--vocabulary-module <path>` for an explicitly
selected unconfigured vocabulary. Ensure the `conceptSet(...)` registration map
and registered class imports use the supported statically resolvable forms
listed in the CLI reference.

Catalog users must select and copy source themselves from `catalog show` and
`catalog source`, then adapt, test, and maintain it as application-owned source.
The catalog no longer updates or validates previously installed files and does
not consume an existing `catalog.lock`. Catalog entry authors must replace
schema-1 destinations, floors, packages, and generated-integration metadata with
the schema-2 `design`, `sources`, and labeled `implementations` fields.

Install core, HTTP, and analysis at `1.0.0-beta.9` when using those packages
together. The catalog may be installed independently at `1.0.0-beta.9`.

### Generated formats

- The canonical application manifest remains version 5, and concept
  specifications remain version 1. Regeneration updates core, analysis, and HTTP
  producer provenance to `1.0.0-beta.9`.
- Catalog entry manifests advance from schema 1 to schema 2. There is no
  `catalog.lock` or generated catalog wiring format in this release.
- Moving declarations into named composition groups can change generated
  reaction paths and ordering without changing endpoint wire shapes or the
  application-manifest format.

### Runtime and security support

- Core, analysis, and HTTP runtime and security behavior are unchanged.
- The catalog no longer writes project files or resolves package requirements.
  Consumers own destination choice, dependency selection, source review,
  integration, testing, updates, and any cleanup of files installed by an older
  catalog.

[Release][1.0.0-beta.9] | [Changes since 1.0.0-beta.8][1.0.0-beta.9-compare]

## [1.0.0-beta.8] - 2026-08-11

This beta adds the curated source catalog and concept-free setup flow, replaces
the HTTP policy and browser-session API, and extends endpoint diagnostics across
linear action chains.

### Compatibility

- Added the CLI-only `@mit-sdg/sync-engine-catalog` package. Its 16 concepts and
  8 recipes install reviewed source for a selected memory or MongoDB floor,
  record ownership in `catalog.lock`, and generate registration and composition
  modules. The catalog never imports generated modules into application-owned
  files.
- `catalog add` validates the complete dependency graph, selected floor, package
  requirements, portable paths, source imports, and existing lock ownership
  before writing. It never rewrites copy-owned source. Schema 1 has no catalog
  migration operation; changed requirements or integration metadata for an
  installed entry are rejected.
- Replaced `sync-engine new` and its example-bearing scaffold with
  `sync-engine setup [directory]`. Setup initializes only missing concept-free
  files in an existing Bun package. It never edits `package.json`, merges an
  existing configuration, or overwrites an application file. `new` has no
  compatibility alias.
- `@mit-sdg/sync-engine-http` now exposes `/policy`, `/handler`, `/client`, and
  `/tooling`. A branded immutable `HttpPolicy` supplies deployment facts to the
  Fetch handler and wire projector; the typed client remains policy-free. The
  package has no `/server` compatibility entrypoint.
- HTTP policy can derive exact-origin CORS, separate request-origin protection,
  multiple secure cookie bindings, public error projection, request-body
  limits, response headers, and correlation. Construction rejects raw mutable
  policy objects and invalid deployment facts. Handler binding and wire
  projection reject policies that disagree with endpoint contracts.
- Endpoint diagnostics now prove coverage and overlap through recognized linear
  action chains whose inputs, successful postures, ancestor reads, and standard
  refusal/fault delivery are total. Assembly reserves the reaction names
  `DeliverRefusalToAsker` and `DeliverFaultToAsker` for those boundary outcomes.
- The shipped message-board browser application demonstrates HTTP sessions,
  request-origin policy, response projection, startup, drain, and shutdown. The
  former production-HTTP example has been replaced.

### Migration

Applications that used `sync-engine new` must create a Bun package, install
core, and run `sync-engine setup`. Add concepts manually or install
`@mit-sdg/sync-engine-catalog@1.0.0-beta.8` and run `catalog add`. Apply the
printed integration guidance: the catalog does not edit the application concept
set, composition, assembly, host, TypeScript configuration, package manifest, or
scripts.

Install core, HTTP, analysis, and catalog at `1.0.0-beta.8` when using those
packages together. Rename application reactions that use either reserved
boundary-outcome name.

The HTTP rework uses the following replacements.

#### Removed HTTP identifiers

| Removed                            | Replacement                         |
| ---------------------------------- | ----------------------------------- |
| `@mit-sdg/sync-engine-http/server` | `@mit-sdg/sync-engine-http/handler` |
| `productionHttpProfile`            | `httpPolicy`                        |
| `ProductionHttpProfile`            | `HttpPolicyInit` / `HttpPolicy`     |
| `HttpPublicErrorPolicy`            | folded into `HttpPolicyInit`        |
| `httpFloor`                        | `httpPolicy({ cookies })`           |
| `HttpFloor`                        | `HttpPolicy`                        |
| `HttpCredentialBinding`            | `HttpCookieBinding`                 |
| `createHttpHandler({ profile })`   | `createHttpHandler({ policy })`     |
| `createHttpHandler({ floor })`     | `createHttpHandler({ policy })`     |

#### Renamed HTTP fields

| Before                          | After                                   |
| ------------------------------- | --------------------------------------- |
| `origin`                        | `publicOrigin` (conditionally required) |
| `credential`                    | `cookies.<name>`                        |
| `credential.issue` (one object) | `cookies.<name>.issue` (array)          |
| `credential.issue.output`       | `cookies.<name>.issue[].value`          |
| `credential.name`               | `cookies.<name>.name`                   |

#### Changed HTTP behavior

| Change                                                                                    | Effect                                                                             |
| ----------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| Raw mutable policies rejected                                                             | Construct policy values with `httpPolicy(...)`.                                    |
| `SameSite` derived; `None` under a credentialed browser policy                            | Cross-origin browser session policy no longer silently receives `Strict`.          |
| HTTPS-or-loopback required whenever cookies are declared                                  | Cookie policy no longer depends on `NODE_ENV`.                                     |
| Client default `credentials: "same-origin"`                                               | Cross-origin browser clients must select `"include"`.                              |
| Clearing scoped to applicable bindings; `FORBIDDEN` excluded                              | Authorization refusal no longer signs out a valid session.                         |
| Construction rejects overlapping bindings, inert bindings, and optional credential inputs | Previously accepted assemblies may fail during handler binding or wire projection. |

Import HTTP policy declarations from `/policy`, pass the same `HttpPolicy` to
the handler and projector, and configure cross-origin browser clients with
`credentials: "include"`. CORS and request-origin protection are separate
controls. A missing `Origin` remains allowed unless
`requestOrigins.requireOrigin` is true.

### Generated formats

- The canonical application manifest remains at version 5. Regeneration updates
  core, analysis, and HTTP producer provenance to `1.0.0-beta.8`.
- Lowered continuation stages now retain stable logic-variable names across the
  complete reaction family. Regenerated manifest and read-back output may differ
  where a later stage reuses a binding from an earlier stage; no persisted format
  version changes.
- Catalog `manifest.json` and `catalog.lock` remain schema 1. A lock records the
  catalog version that first installed each entry as provenance; it is not an
  update marker.

### Runtime and security support

- Cookie policy always enforces `HttpOnly` and `Secure`, derives `__Host-` or
  `__Secure-` names, bounds cookie headers and serialized cookies, and requires
  HTTPS or loopback deployment. Credentialed cross-origin policy derives
  `SameSite=None` and cannot disable request-origin protection.
- CORS controls browser response access; request-origin policy separately guards
  cookie-protected, issuing, and clearing routes. Neither authenticates a user or
  authorizes domain behavior. The host still owns TLS, proxy trust, traffic
  controls, static routing, and process lifecycle.
- Catalog entries are application source, not an opaque runtime dependency.
  Applications must review installed code, select and operate the storage floor,
  apply generated integration explicitly, and retain `catalog.lock`. MongoDB
  transaction requirements remain application and deployment responsibilities.
- Endpoint coverage diagnostics prove the recognized static chain shape after a
  watched posture lands. They do not prove that actions or reads settle, that
  runtime values match TypeScript types, or that live object identity is
  portable.
- The beta publication workflow now verifies and packs every workspace before
  one protected npm environment approval, then publishes the reviewed tarballs
  in dependency order. Publication still stops at the first registry failure and
  never overwrites an accepted package version.

[Release][1.0.0-beta.8] | [Changes since 1.0.0-beta.7][1.0.0-beta.8-compare]

## [1.0.0-beta.7] - 2026-08-07

This beta advances the canonical application manifest and publishes a lean,
two-surface analysis companion for the first time.

### Compatibility

- The canonical `sync-engine.application-manifest` format advances to V5.
  `ApplicationManifestV5` and `ManifestEndpointV5` replace the version-4 public
  type names; V4 input is rejected rather than upgraded.
- `@mit-sdg/sync-engine-analysis` is now a public package with supported
  `/ir` and `/project` entrypoints and an exact
  `@mit-sdg/sync-engine@1.0.0-beta.7` peer.
  There was no published analysis beta.6; beta.7 is its first public release.
- `/ir` provides compiler-free manifest, graph, source-data, and neutral facade
  queries. `/project` owns TypeScript-backed source indexing, filesystem and
  worker analysis, project diagnostics and producer options, and strict project
  codecs. TypeScript `>=6 <7` is an analysis runtime dependency, not a peer, but
  importing `/ir` does not evaluate it.
- The unpublished oversized preview surface has been removed without aliases:
  there is no `/tooling`, `/guidance`, persisted granular-result codec, impact
  context bundle, change target, review orchestration, packaged guidance, or
  workflow-shaped supporting API.
- Durable source indexes retain only document and anchor metadata, ranges, and
  digests. Source-text search, retained anchor/excerpt text, full-text
  descriptions, source content modes, facade contract rendering, and
  caller-supplied wire projections are removed.
- Project-backed facade construction recomputes the canonical manifest index and
  rejects even a structurally self-consistent project index when its semantic
  composition differs from the supplied manifest. Supplying a project now also
  requires a caller-held `expectedProjectDigest`; optional `limits` govern the
  canonical recomputation.

### Migration

- Upgrade core and HTTP to `1.0.0-beta.7` together. When adopting analysis,
  install `@mit-sdg/sync-engine-analysis@1.0.0-beta.7` alongside that exact core
  beta; do not infer an analysis beta.6 package from the core release history.
- Regenerate checked-in application manifests, assembled Markdown, and wire
  TypeScript. Replace V4 manifest type imports with V5. Preview analysis clients
  must replace `/tooling` imports with `/ir` and/or `/project` and move prompts,
  guidance, context packing, targeting, review, observations, and coverage policy
  into their own application.
- Use `readApplicationSourceDocument(...)` with a caller reader to obtain and
  verify a complete source document, then slice it with returned anchor ranges.
  Replace facade source models with `ApplicationSourceQuery` and
  `SourceQueryMatchMode`; consume raw logical contracts without render modes or
  projection evidence.
- Retain `applicationProjectAnalysisDigest(project)` at the point where a project
  artifact is trusted, then pass it as `expectedProjectDigest` when constructing
  a project-backed facade. Computing both artifact and digest from the same
  untrusted input chooses that artifact rather than authenticating it.

### Generated formats

- Manifest V5 adds complete standard and vocabulary computation inventory plus
  canonical-versus-selected concept implementation provenance. It records
  serializable attribution, not functions, constructor arguments, resources,
  source paths, object identity, concept state, or other runtime state.
- `sync-engine.application-index` version 2,
  `sync-engine.impact-trace` version 2,
  `sync-engine.application-source-index` version 2, and
  `sync-engine.application-project-analysis` version 2 carry exact manifest,
  analyzer, core-generator, and, where available, source-revision and
  source-digest identity. Format versions govern structural compatibility;
  exact producer versions remain provenance.
- Granular facade results are immutable and byte-bounded with one canonical size
  pass, but are not a persisted format and have no parse, render, validate, or
  digest API. The V2 project snapshot remains the durable analysis artifact.
- Project V2 snapshots have strict canonical JSON validation, parsing,
  rendering, and SHA-256 identity. Validation binds nested index/source data,
  source metadata and ranges, all read-file digests, TypeScript versions,
  diagnostics, ordering, and resource usage. Snapshots contain no source bytes.
  File records add exact UTF-8 `byteLength`; `projectBytes` is the sum of the
  ordered unique records. Source issue refs must be inventory refs, and candidate
  ranges must belong to indexed documents.

### Runtime and security support

- Source attribution uses the supplied TypeScript program without importing or
  executing project modules or manifest-producing configuration. Static-flow,
  AST, traversal, pagination, source-document, source-read, and result-byte limits fail closed or
  report incomplete evidence instead of silently claiming completeness.
- Filesystem analysis follows complete transitive TypeScript project references
  from source, rejects config/source/extends/symlink escapes and cycles, and does
  not require built declarations. The async API runs in an emitted Node worker;
  abort terminates it without returning a partial snapshot. Synchronous compiler
  parsing and program creation remain checkpoint-bounded rather than
  timer-preemptive.
- Analysis is generic, deterministic inspection infrastructure. Possible-impact
  and source attribution remain evidence with explicit limits; no analysis API
  proves runtime behavior, packages workflow advice, authorizes a change, or
  returns an approval verdict.
- Packed Node 24 verification imports `/ir` in isolation and rejects any runtime
  load of TypeScript, `fs`, `fs/promises`, `node:fs`, `node:fs/promises`, worker,
  project-loader, or source-index-builder modules. Exact-tarball Node 24 and Bun
  consumers exercise `/project`.
- Revision strings are caller assertions rather than Git verification. Project
  parsing synchronously consumes a complete supplied string without its own size
  bound; hosts must bound untrusted input before calling it.
- Codec validation proves shape and derivable consistency, not semantic source
  attribution. AST counts remain producer-reported. Only comparison with a
  previously trusted complete project digest authenticates an unchanged
  artifact; an attacker-chosen artifact and digest remain attacker-chosen unless
  TypeScript analysis is rerun from trusted inputs.

[Release][1.0.0-beta.7] | [Changes since 1.0.0-beta.6][1.0.0-beta.7-compare]

## [1.0.0-beta.6] - 2026-08-06

This beta makes authored concept contracts structured, preserved, and
project-aware while keeping their descriptive boundary explicit.

### Compatibility

- Concept specifications now use a balanced, location-aware grammar for action
  and query signatures. The parser retains structured input and result types,
  normalized member bodies, refusal sentences, `Types`, and extension sections;
  query declarations may include indented reader-facing prose.
- `registerConcept(...)` checks action and query names in both directions,
  recoverable input names, and exact refusal mappings. Parsed types, results,
  bodies, and documentation remain descriptive: they do not infer runtime
  schemas or executable behavior. Engine-evaluated reads continue to enforce
  declared query cardinality.
- `sync-engine check` resolves finite TypeScript input shapes through the
  nearest project, including supported interfaces, aliases, re-exports,
  intersections, mapped and utility types, and path mappings. Ambiguous,
  unresolved, open, cyclic, or otherwise unsupported shapes fail closed with
  source diagnostics.

### Migration

- Correct concept files that relied on partially parsed or malformed signatures,
  duplicate declaration sections, misplaced declaration fences, invalid refusal
  lines, or trailing signature text. Ensure each direct class method has one
  supported finite input shape when using `sync-engine check`.
- Regenerate checked-in application manifests and Markdown read-back. State
  notation remains reader-only and is intentionally excluded from parsed
  contracts and generated artifacts.

### Generated formats

- Application manifests remain at version 4 and may now include a
  `sync-engine.concept-specification` version-1 subtree for each registered
  concept. The subtree preserves authored signatures, bodies, refusals,
  documentation, and source locations. Generated Markdown renders that contract
  and identifies the manifest producer, concept-specification format, and
  renderer versions.

### Runtime and security support

- None.

[Release][1.0.0-beta.6] | [Changes since 1.0.0-beta.5][1.0.0-beta.6-compare]

## [1.0.0-beta.5] - 2026-08-05

This entry adds deferred triggers: a composition can hold a consequence until
tracked ordinary work in the trigger's causal flow has drained, without a host
idle wait.

### Compatibility

- `when(...)` and every chained stage, including an endpoint's, accept
  `.afterFlowSettles()`. The stage's conditions are read at each settlement
  frontier until the trigger match produces one or more bindings or the flow
  finalizes. Each surviving binding is dispatched independently. Settlement is
  per causal flow: unrelated root flows neither delay a frontier nor open one.
  See [Deferred triggers and settlement
  frontiers](docs/user/reference/semantics.md#deferred-triggers-and-settlement-frontiers).
- A deferred consequence keeps flow identity, `earlier(...)` scope, request
  correlation, firing provenance, and execution-limit accounting. Interpreter
  or integrity failure recorded before a frontier stops deferred advancement.
  A deferred endpoint path that never qualifies produces no answer; ordinary
  endpoint settlement still determines whether another path answers, the request
  times out, or an interpreter failure produces `INTERNAL_ERROR`.
- Registration rejects `.afterFlowSettles()` on a later stage of a chain that
  lowering keeps local, naming the stage: a deferred stage must lower into a
  reaction of its own.

### Migration

- Existing compositions require no authoring changes; a reaction without
  `.afterFlowSettles()` fires exactly where its trigger lands. Replace
  `ApplicationManifestV3` and `ManifestEndpointV3` imports with their version-4
  counterparts, and regenerate checked-in version-3 manifests. Version-4
  artifact planning rejects version 3.
- Application workflows that used `whenIdle()` only to wait for ordinary
  consequences in one causal flow can state that order in the composition
  instead.

### Generated formats

- `ReactionIR` gains an optional `deferred` flag. It is absent unless a stage
  states `.afterFlowSettles()`. Because older tooling would otherwise interpret
  that reaction as immediate, the application manifest format advances to
  version 4, with `ApplicationManifestV4` and `ManifestEndpointV4` replacing the
  version-3 public types. Regenerate version-3 manifests when upgrading.
  Read-back and rendered reactions identify deferred timing as
  `at the flow's settlement frontier`.

### Runtime and security support

- None.

[Release][1.0.0-beta.5] | [Changes since 1.0.0-beta.4][1.0.0-beta.5-compare]

## [1.0.0-beta.4] - 2026-08-04

This beta tightens assembly, validation, persistence, client, transport, and
read contracts while keeping application policy and infrastructure choices
outside the engine.

### Compatibility

- The supported package subpaths include `/advanced`, but beta compatibility
  remains version-specific. Only the newest beta is supported.
- `conceptSet(registrations, computations?)` installs named computations while
  retaining their names and function signatures on `set.computations` and
  `set.vocabulary.computations`.
- Ordinary `assemble(...)` applications reject undeclared advanced refusal
  codes. Manual `createEngine(...)` assembly remains open for advanced hosts.
- Occurrence retention is split from audit export: `MemoryStore` is no longer a
  public hosting contract, `LogSink` is the synchronous application-owned audit
  extension, and `FileLogSink` provides append-only JSONL output.
  `RetentionPolicy` now contains only `"keepAll"` and `{ window: number }`.
- Query declarations now statically connect cardinality metadata to result
  containers. Mutable HTTP and boundary policies are snapshotted when their
  handlers or projectors are constructed.
- Promise-compatible extension points accept structural thenables consistently.

### Migration

- `createEngine(store?: LogStore)` is now
  `createEngine(options?: EngineOptions)`. Occurrence stores are no longer
  replaceable; every engine owns its internal occurrence index. Pass
  `{ retention, logSink }` to configure retention and an audit destination.
  Replace public `MemoryStore` or `FileStore` use with a `LogSink`, such as
  `FileLogSink`, and pass it to `assemble(...)` as `logSink` rather than
  `logStore`. Capture complete, redacted audit evidence through `LogSink`.
  `inspectAssembly(...).occurrences` is only a redacted summary of action
  occurrences still retained by the internal index; it is not an audit stream.
- Replace beta `retention: "evictConsumed"` with `{ window: number }` for a
  bounded number of settled flows or `"keepAll"` for no automatic eviction.
  Ordinary `assemble(...)` defaults to `{ window: 100 }`; `createEngine(...)`
  defaults to `"keepAll"`. Window enforcement runs automatically only after a
  flow settles. Stable v1 exposes no manual prune operation.
- A custom `LogSink.append(entry)` must return `undefined` synchronously. A
  throw or any returned value, including a promise or structural thenable,
  fails the append before the internal index folds the entry.
- Declare every advanced refusal code used by an ordinarily assembled
  application. Hosts intentionally assembling engines manually may continue to
  define refusal policy outside the engine.
- Update query result types to agree with their declared cardinality. TypeScript
  now requires `count(...)` to receive the query's complete input mapping,
  rejects extra fields at every nested level, and rejects union-typed query
  references. Adjust
  custom client transports to carry `timeoutMs` and `correlationId` when those
  per-call options are used.
- Install `@mit-sdg/sync-engine-http@1.0.0-beta.4` with the exact matching core
  beta.
- Regenerate checked-in application manifests, assembled read-back, and wire
  contracts. Expanded endpoint analysis can change advisory diagnostics, and
  corrected optional former results can change generated TypeScript.

### Generated formats

- Application manifest format remains version 3. Generator and projector
  provenance accepts valid Semantic Versioning, including prereleases.
- Regenerate checked-in artifacts so generator and HTTP projector provenance
  records `1.0.0-beta.4`.

### Runtime and security support

- Endpoint success values and declared domain errors can be validated at the
  invocation boundary. Invalid domain errors become integrity evidence rather
  than trusted application responses.
- Privileged `RawFaultReporter` hooks can receive action, interpreter, and
  validator faults without exposing raw failures to ordinary clients; reporter
  failures are isolated.
- Clients can validate complete success-or-error responses and carry per-call
  timeout and correlation context. The HTTP client supports caller timeouts and
  opt-in streaming response-size limits.
- Query caching is explicit through `"memoize"` and `"none"` modes, allowing
  applications to disable memoization without replacing engine policy.
- Endpoint diagnostics trace causal `by` provenance and distinguish potential
  overlap from proved direct-path overlap. They recognize canonical request
  shapes, disjoint literal alternatives, non-dropping `whether` lines, and
  fresh computations.
- Generated endpoint results include `null` when an endpoint directly returns
  an optional former, and blank optional splices retain all recursively
  contributed keys with `null` leaves.
- Beta publication uses immutable annotated tags and verified tarballs,
  publishes core under `beta`, and publishes HTTP only after core succeeds.

[Release][1.0.0-beta.4] | [Changes since 1.0.0-beta.3][1.0.0-beta.4-compare]

## [1.0.0-beta.3] - 2026-07-30

This maintenance beta corrects reaction scheduling, matching, registration, and
HTTP error projection defects found during a runtime audit.

### Compatibility

- Public package exports are unchanged. Trigger and `where` stages for reactions
  observing one landed occurrence now finish before any matching consequence is
  dispatched. A sibling consequence can no longer change another sibling's
  guard result.
- Consequence inputs containing `bigint` now fail registration. Earlier betas
  accepted these values but delivered an internal marker object to the action.
- Serialized `oneOf` candidates now use structural equality and preserve escaped
  literal data. Imported opaque candidates without their definition-site value
  fail registration instead of installing an inert trigger.

### Migration

- Replace `bigint` consequence literals with portable JSON data, or derive the
  value at firing time with a registered computation.
- Remove any dependency on one reaction consequence changing a sibling
  reaction's `where` result for the same occurrence. Such ordering was never a
  supported priority mechanism.

### Generated formats

- None.

### Runtime and security support

- Requested guards no longer run again for outcome landings, and opposite-order
  requested consequences no longer deadlock concurrent flows.
- Failed replacement registration leaves the previous reaction family intact.
  Repeated variables and optional serialized bindings now use the documented
  unification and blank-propagation rules.
- Production HTTP wire projection no longer exposes unmapped domain errors that
  runtime handling reports as `INTERNAL_ERROR`.

[Release][1.0.0-beta.3] | [Changes since 1.0.0-beta.2][1.0.0-beta.3-compare]

## [1.0.0-beta.2] - 2026-07-30

HTTP transport support now ships as the independently published
`@mit-sdg/sync-engine-http` first-party package.

### Compatibility

- This intentional beta breaking change removes HTTP handler, profile, floor,
  fetch client, and HTTP client-error exports from core. Core remains usable
  without the companion package through `createClient<Wire>({ transport })` and
  `bindTransport({ application, gateway })`.
- `@mit-sdg/sync-engine-http` provides `/server`, `/client`, and `/tooling` and
  requires the exact matching core beta as a peer dependency.

### Migration

- Install both exact packages, move server imports to
  `@mit-sdg/sync-engine-http/server`, client imports to `/client`, and wire
  projection imports to `/tooling`.
- Move public domain-error mappings from concept registrations into the reused
  HTTP policy value's `publicErrors` field. Replace `PublicError` members with
  the corresponding HTTP category strings, such as `"CONFLICT"`.
- Replace `httpProfile`, `httpFloor`, and `httpWireName` in `generated.config.ts`
  with `projections: [httpWire({ policy, name })]`, then regenerate artifacts.
- Replace references to HTTP failures on `FrameworkErrorCode` with
  `HttpClientErrorCode`. Generic clients using the HTTP transport should use
  `Client<Wire, HttpClientError>` or `createClient<Wire, HttpClientError>(...)`;
  `createHttpClient<Wire>(...)` supplies that error type directly.
- `GeneratedApplication` is now exported from the core `/tooling` subpath for
  typing application-owned generation descriptors.

### Generated formats

- Generated wire provenance now records every projector package and version.
- Logical wire remains canonical; each projection appends a named transport
  contract to the same generated module.

### Runtime and security support

- Core has no HTTP runtime or type dependency. The companion policy owns HTTP
  status, cookies, origin, correlation, fetch, and public-error projection.
- CI and publication verify both independently packed tarballs before either
  package can be published.

[Release][1.0.0-beta.2] | [Changes since 1.0.0-beta.1][1.0.0-beta.2-compare]

## [1.0.0-beta.1] - 2026-07-29

The beta.0 publication attempt did not reach npm because its publish command
treated the packed tarball path as a Git source. Beta.1 corrects that release
automation without changing the package's public behavior.

### Compatibility

- No public API or behavior changes from beta.0.

### Migration

- None.

### Generated formats

- None.

### Runtime and security support

- The protected publication job passes the verified tarball as an explicit local
  path to npm.

[Release][1.0.0-beta.1] | [Changes since 1.0.0-beta.0][1.0.0-beta.1-compare]

## [1.0.0-beta.0] - 2026-07-28

The beta cutover completes the support, compatibility, production-boundary,
operational-control, and release-supply-chain work audited after alpha.0. It
defines six explicit public subpaths and makes their beta expectations
and generated-contract coupling explicit.

### Compatibility

- The supported package surface remains `/language`, `/assembly`, `/boundary`,
  `/client`, `/tooling`, and `/advanced`. Root and deep imports remain
  unsupported. Beta releases may make incompatible changes with release-specific
  migration notes; `/advanced` remains the highest-churn public surface.
- `compute` moves from `/advanced` to `/language`. The process-level `/utils`
  entrypoint and the implementation-level `Requesting` and `refusalFunnel`
  exports are removed.
- The supported ranges are Node.js `>=24 <25`, Bun `>=1.3.14 <1.4`, and
  TypeScript `>=6 <7`. Current Linux, macOS, and Windows GitHub-hosted runners
  exercise package and test behavior.
- Only the newest beta is supported. Alpha releases are unsupported at beta.0,
  and the newest beta support window ends 30 days after stable 1.0.0 unless a
  later policy extends it. Published versions remain immutable.
- Endpoint declarations provide the authoritative route set. Endpoint and HTTP
  base paths use canonical portable URL pathnames, and deployment prefixes are
  explicit.

### Migration

- Move runtime deployments to Node.js 24 and keep Node below 25. Run the CLI,
  examples, and source scripts with Bun 1.3.14 through the 1.3 line, and use
  TypeScript 6 through the 6.x line.
- Use manual engines under `/advanced` for closures, custom operations,
  object-identity patterns, raw transforms, and whole unlowered definitions.
  Ordinary `assemble(...)` accepts portable reactions, views, and formers.
- Import `compute` from `/language`. Configure redaction through
  `AssemblyOptions.redaction`; hosts own any standalone logging, redaction, or
  diagnostic helpers. There is no public replacement for `Requesting` or
  `refusalFunnel`.
- Treat each endpoint's declared path as authoritative, leave framework-owned
  `path` and `requestId` fields to `receive(...)`, canonicalize endpoint/base
  paths, and declare `basePath: "/api"` explicitly when needed.
- Add `UNAVAILABLE` handling for overload and drain results and make switches
  over framework error codes exhaustive. Admission rejected for overload or
  drain creates no root action occurrence.
- Account for interpreter settlement: when an unanswered request becomes
  quiescent after an interpreter failure, ordinary assembly settles it promptly
  as opaque `INTERNAL_ERROR`; a response already delivered remains authoritative.
- Integrate `Assembly.beginDrain()` / `Assembly.whenIdle()` and
  `Gateway.beginDrain()` / `Gateway.whenIdle()` into host shutdown. Draining
  stops new roots but waits for accepted causal work, including work outliving a
  caller timeout or abort.
- Configure the standard gateway as an `Invoker` decorator. Use its observer for
  limit, drain, and final settlement events and the application store for
  occurrence evidence.
- Consumers of inspected IR must handle `UnloweredIR.known`, which retains the
  triggers, reads, consequences, and patterns that remain knowable around an
  opaque whole definition.
- Use `productionHttpProfile(...)` for public error projection. Add
  `httpFloor(...)` only when the application needs its narrow same-origin cookie
  binding; credential meaning and domain authorization remain application
  responsibilities.
- Configure execution limits, retention, redaction, endpoint validators, and
  bounded operational observers. Use the final `invocation-settled` event for
  request metrics, and call drain methods before closing host-owned floors,
  stores, listeners, or process resources.
- `FileStore` composes a live in-memory occurrence index with an append-only
  JSONL audit sink.
- Artifact commands and `planGenerated(...)` share one manifest-driven
  rendering pipeline.
- Own application redaction through `AssemblyOptions.redaction`; universal
  sensitive-name patterns remain active alongside application fields and patterns.
- Keep a concept specification's optional State section as prose only. It is
  not checked against class fields or storage and does not enter manifests,
  read-back, wire types, input contracts, or runtime validators; prove state
  properties in principle, implementation, and backend constraint tests.

### Generated formats

- Regenerate and review generated Markdown and wire TypeScript after upgrading.
  Generated clients, server assemblies, and generation tooling must use the
  same exact package version; cross-version generated contracts are unsupported.
- `sync-engine.application-manifest` V3 is the current versioned format. It
  carries static application design, endpoint contracts, diagnostics, and its
  digest. Format-version equality does not relax exact package-version coupling.
- Regenerate declarations and all pinned example artifacts before cutting the
  beta. Endpoint input contracts, validator presence, diagnostics, and
  state-prose exclusion are reflected in the current generated surfaces as
  documented.

### Runtime and security support

- Production HTTP handlers enforce bounded POST JSON handling and public error
  projection; the optional cookie floor enforces same-origin credential
  transport. Hosts still own TLS, HSTS, CORS, trusted proxies, connection and
  rate limits, DDoS controls, authentication integration, and process lifecycle.
- Execution limits bound engine-owned admission and causal work. Operational
  observers receive value-free stable events, while application logs and custom
  stores remain sensitive sinks subject to host retention and access controls.
- Vulnerabilities use GitHub private vulnerability reporting. The supported
  security-fix window, acknowledgement targets, coordinated disclosure process,
  and host/application boundary are defined in [SECURITY.md](SECURITY.md).

[Release][1.0.0-beta.0] | [Changes since 1.0.0-alpha.0][1.0.0-beta.0-compare]

## [1.0.0-alpha.0] - 2026-07-27

The first v1 alpha replaces, rather than extends, the 0.3 architecture. It adds
registered concept specifications, fluent reaction declarations, views and
formers, application assembly, generated wire contracts, local/HTTP clients,
and a package-qualified `sync-engine` CLI. The package now ships built ESM
JavaScript and declarations instead of exposing its TypeScript sources.

### Migrating from 0.3

There is no drop-in migration. Rebuild composition around a vocabulary,
registered concepts, reactions, and an assembly; then expose selected behavior
through endpoints. The [guides](docs/guide/getting-started.md) and [public API
register](docs/public-surface.md) describe the new architecture.

| 0.3 entrypoint                                                                            | v1 alpha direction                                                                                                                                                                          |
| ----------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Package root and `/engine`                                                                | Removed. Use `/language` for declarations, `/assembly` for registration and assembly, and `/advanced` only for manual engine construction. The old declaration-tree API requires a rewrite. |
| <code>/s&#100;k</code>, <code>/s&#100;k/client</code>, <code>/s&#100;k/http-client</code> | Use `/boundary` to author endpoints and adapters, and `/client` to consume generated contracts. The endpoint DSL is redesigned.                                                             |
| <code>/s&#100;k/cli-client</code>                                                         | Removed. `/boundary` provides inbound CLI application adapters, not a drop-in outbound CLI client.                                                                                          |
| `/runtime`                                                                                | Removed. Assembly, log stores, gateways, and boundary floors now own these responsibilities; there is no direct `AppHost` or `Lifecycle` replacement.                                       |
| `/utils`                                                                                  | Remains `/utils`, with a smaller logging, redaction, and error-serialization surface; audit imports individually.                                                                           |
| `/devtools/graph`                                                                         | Removed in 0.2. `/tooling` now provides assembly inspection, read-back, and contract generation, but not a compatible graph API.                                                            |

### Alpha stability

| Public subpath | Compatibility expectation                                            |
| -------------- | -------------------------------------------------------------------- |
| `/language`    | Alpha; authoring syntax and inferred types may change.               |
| `/assembly`    | Alpha; registration, hosting, and persistence contracts may change.  |
| `/boundary`    | Alpha; endpoint and transport contracts may change.                  |
| `/client`      | Alpha; generated contract and client shapes may change together.     |
| `/tooling`     | Alpha; IR, read-back, and generated output may change.               |
| `/advanced`    | Alpha and deliberately low-level; expect the most churn.             |
| `/utils`       | Alpha; no compatibility guarantee despite the retained subpath name. |

Generated files are pinned outputs, not a stable interchange format. Execution,
persistence, restart, validation, and resource bounds are documented under
[operational limits](docs/semantics.md#operational-limits).

The current manifest correctly declares `Apache-2.0`, matching the repository's
license. Published 0.1-0.3 manifests incorrectly declared `MIT`; this metadata
correction does not alter those already-published tarballs.

[Release][1.0.0-alpha.0] | [Changes since 0.3.0][1.0.0-alpha.0-compare]

## [0.3.0] - 2026-07-10

- Replaced the sequencing and branching DSL and added bracket extractors and
  branch predicates.
- Generalized clients around transports.
- Hardened lifecycle, caches, matching, logging, HTTP/CLI handling, and
  concurrent application hosting.
- Tightened query and binding inference and expanded tests and API guides.

[Release][0.3.0] | [Changes since 0.2.0][0.3.0-compare]

## [0.2.0] - 2026-07-08

- Removed the devtools package surface and consolidated the package to one root
  export while retaining engine, client, and runtime source directories.

[Tag][0.2.0] | [Changes since 0.1.1][0.2.0-compare]

## [0.1.1] - 2026-07-08

- Reworked the endpoint DSL to follow the engine's declaration syntax.

[Tag][0.1.1] | [Changes since 0.1.0][0.1.1-compare]

## [0.1.0] - 2026-07-08

- Initial public package with declarative cross-concept reactions over an
  append-only occurrence log, frames-based matching, nested workflows, an
  endpoint/client layer, multi-tenant runtime helpers, utilities, and graph
  devtools.

[Release][0.1.0]

[1.0.0-beta.18]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.18
[1.0.0-beta.18-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.17...v1.0.0-beta.18
[1.0.0-beta.17]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.17
[1.0.0-beta.17-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.16...v1.0.0-beta.17
[1.0.0-beta.16]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.16
[1.0.0-beta.16-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.15...v1.0.0-beta.16
[1.0.0-beta.15]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.15
[1.0.0-beta.15-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.14...v1.0.0-beta.15
[1.0.0-beta.14]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.14
[1.0.0-beta.14-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.13...v1.0.0-beta.14
[1.0.0-beta.13]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.13
[1.0.0-beta.13-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.12...v1.0.0-beta.13
[1.0.0-beta.12]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.12
[1.0.0-beta.12-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.11...v1.0.0-beta.12
[1.0.0-beta.11]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.11
[1.0.0-beta.11-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.10...v1.0.0-beta.11
[1.0.0-beta.10]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.10
[1.0.0-beta.10-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.9...v1.0.0-beta.10
[1.0.0-beta.9]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.9
[1.0.0-beta.9-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.8...v1.0.0-beta.9
[1.0.0-beta.8]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.8
[1.0.0-beta.8-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.7...v1.0.0-beta.8
[1.0.0-beta.7]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.7
[1.0.0-beta.7-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.6...v1.0.0-beta.7
[1.0.0-beta.6]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.6
[1.0.0-beta.6-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.5...v1.0.0-beta.6
[1.0.0-beta.5]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.5
[1.0.0-beta.5-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.4...v1.0.0-beta.5
[1.0.0-beta.4]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.4
[1.0.0-beta.4-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.3...v1.0.0-beta.4
[1.0.0-beta.3]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.3
[1.0.0-beta.3-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.2...v1.0.0-beta.3
[1.0.0-beta.2]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.2
[1.0.0-beta.2-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.1...v1.0.0-beta.2
[1.0.0-beta.1]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.1
[1.0.0-beta.1-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-beta.0...v1.0.0-beta.1
[1.0.0-beta.0]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-beta.0
[1.0.0-beta.0-compare]: https://github.com/mit-sdg/sync-engine/compare/v1.0.0-alpha.0...v1.0.0-beta.0
[1.0.0-alpha.0]: https://github.com/mit-sdg/sync-engine/releases/tag/v1.0.0-alpha.0
[1.0.0-alpha.0-compare]: https://github.com/mit-sdg/sync-engine/compare/v0.3.0...v1.0.0-alpha.0
[0.3.0]: https://github.com/mit-sdg/sync-engine/releases/tag/v0.3.0
[0.3.0-compare]: https://github.com/mit-sdg/sync-engine/compare/v0.2.0...v0.3.0
[0.2.0]: https://github.com/mit-sdg/sync-engine/tree/v0.2.0
[0.2.0-compare]: https://github.com/mit-sdg/sync-engine/compare/v0.1.1...v0.2.0
[0.1.1]: https://github.com/mit-sdg/sync-engine/tree/v0.1.1
[0.1.1-compare]: https://github.com/mit-sdg/sync-engine/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/mit-sdg/sync-engine/releases/tag/v0.1.0
